/* Screen library: every screen in COURSE_DATA.lessons[].screens has a "type". Bilingual (T), RTL-aware (CSS logical properties). */
(function () {
  var E = window.ENGINE, D = window.COURSE_DATA, T = window.T, LT = window.LETTERS;
  var ico = function (n) { return window.ico(n); }, icl = function (n) { return window.icl ? window.icl(n) : window.ico(n); };
  function q(c, s) { return c.querySelector(s); }
  function qa(c, s) { return Array.prototype.slice.call(c.querySelectorAll(s)); }
  function esc(t) { return String(t == null ? '' : t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function rich(t) { return esc(t).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>'); }
  var SHUF = window.SHUF = window.SHUF || function (n) { var a = []; for (var i = 0; i < n; i++) a.push(i); for (var j = n - 1; j > 0; j--) { var r = Math.floor(Math.random() * (j + 1)), t = a[j]; a[j] = a[r]; a[r] = t; } return a; };
  function paras(t) { return (Array.isArray(t) ? t : (t ? [t] : [])).map(function (p) { return '<p>' + rich(p) + '</p>'; }).join(''); }
  function media(s) {
    if (s.diagram) return '<div class="x-med x-dmed">' + dia(s.diagram, false) + '</div>';
    if (s.video) return '<div class="x-med"><video src="' + s.video + '"' + (s.poster ? ' poster="' + s.poster + '"' : '') + ' controls playsinline preload="metadata"></video></div>';
    if (s.image && /\.png$/i.test(s.image)) { /* object picture → light motion graphic: floating object, rotating rings, light sweep, letters popping in */
      var BP = [[80, 13], [88, 58], [50, 87], [12, 62], [18, 15]];
      return '<div class="x-med x-obj"><span class="x-ring r1"></span><span class="x-ring r2"></span><img src="' + s.image + '" alt=""><span class="x-shine"></span>' +
        (s.badges || []).map(function (b, i) { var p = BP[i % BP.length]; return '<span class="x-bdg" style="left:' + p[0] + '%;top:' + p[1] + '%;animation-delay:' + (0.6 + i * 0.45) + 's,' + (2 + i * 0.45) + 's"><b>' + esc(b[0]) + '</b>' + (b[1] ? '<small>' + esc(b[1]) + '</small>' : '') + '</span>'; }).join('') + '</div>'; }
    if (s.image) return '<div class="x-med"><img src="' + s.image + '" alt=""></div>';
    return '';
  }
  /* narration then callback; screens without narration text finish at once */
  function say(a, id, cues, done) { if (window.TXT && window.TXT[id]) a.say(id, cues || [], done); else if (done) a.later(300, done); }
  /* complete when every listed condition has been met */
  function gate(a, names) { var left = {}; names.forEach(function (n) { left[n] = 1; }); return function (n) { delete left[n]; if (!Object.keys(left).length) a.complete(); }; }
  function reveal(a, c) { a.later(40, function () { qa(c, '.fx').forEach(function (e) { a.reveal(e); }); }); }
  function code(s) { return (D.code || 'COURSE') + '_L' + s.n; }
  var R = {};


  /* ---------- diagrams that mirror the source infographics (brand colours) ---------- */
  function dia(s, on) {
    var L = s.layout, it = s.items || [], b = function (i, cls, inner, style) { return '<button class="dg-n ' + (cls || '') + '" data-i="' + i + '"' + (style ? ' style="' + style + '"' : '') + (on ? '' : ' tabindex="-1"') + '>' + inner + '</button>'; };
    var lab = function (x) { return (x.icon ? '<span class="dg-ic">' + icl(x.icon) + '</span>' : '') + '<b>' + rich(x.title) + '</b>' + (x.sub ? '<small>' + esc(x.sub) + '</small>' : ''); };
    var arrow = '<defs><marker id="dgA" viewBox="0 0 10 10" refX="4" refY="5" markerWidth="42" markerHeight="42" markerUnits="userSpaceOnUse" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="context-stroke"/></marker></defs>';
    if (L === 'cycle') {
      var N = it.length, R0 = 200, gap = N > 4 ? 22 : 17, arcs = '', P = [];
      for (var k = 0; k < N; k++) { var t = (-90 + k * 360 / N) * Math.PI / 180; P.push([50 + 33.333 * Math.cos(t), 50 + 33.333 * Math.sin(t)]);
        var a0 = (-90 + k * 360 / N + gap) * Math.PI / 180, a1 = (-90 + (k + 1) * 360 / N - gap) * Math.PI / 180;
        arcs += '<path d="M' + (300 + R0 * Math.cos(a0)).toFixed(1) + ' ' + (300 + R0 * Math.sin(a0)).toFixed(1) + ' A' + R0 + ' ' + R0 + ' 0 0 1 ' + (300 + R0 * Math.cos(a1)).toFixed(1) + ' ' + (300 + R0 * Math.sin(a1)).toFixed(1) + '" class="' + (k % 2 ? 'a2' : 'a1') + '" marker-end="url(#dgA)"/>'; }
      return '<div class="dg dg-cycle"><svg viewBox="0 0 600 600" aria-hidden="true">' + arrow + arcs + '</svg>' + (s.center ? '<div class="dg-ctr">' + icl(s.center) + '</div>' : '') +
        it.map(function (x, i) { return b(i, 'dg-c' + (N > 4 ? ' sm' : ''), lab(x), 'left:' + P[i][0] + '%;top:' + P[i][1] + '%'); }).join('') + '</div>';
    }
    if (L === 'stack') {
      return '<div class="dg dg-stack">' + it.map(function (x, i) { return b(i, 'dg-blk', '<span class="dg-st"><i></i><i></i><i></i></span><b>' + rich(x.title) + '</b>' + (x.sub ? '<small>' + esc(x.sub) + '</small>' : ''), 'width:' + (78 - i * 6) + '%;margin-inline-start:' + (i * 4) + '%'); }).join('') + '</div>';
    }
    if (L === 'stairs') {
      return '<div class="dg dg-stairs">' + it.map(function (x, i) { return '<div class="dg-sc">' + b(i, 'dg-sb', '<b class="dg-no">' + (i + 1) + '</b><span>' + rich(x.title) + '</span>' + (x.sub ? '<small>' + esc(x.sub) + '</small>' : ''), 'height:' + (30 + i * 15) + '%') + '</div>'; }).join('') + '</div>';
    }
    if (L === 'arrow3') {
      return '<div class="dg dg-a3"><svg viewBox="0 0 900 300" aria-hidden="true">' + arrow + '<path d="M40 120 L840 120" class="a2" marker-end="url(#dgA)"/></svg>' +
        it.map(function (x, i) { return b(i, 'dg-ring' + (i === it.length - 1 ? ' tg' : ''), '<span class="dg-ri"></span><b>' + rich(x.title) + '</b>' + (x.sub ? '<small>' + esc(x.sub) + '</small>' : ''), 'left:' + (16 + i * 34) + '%'); }).join('') + '</div>';
    }
    if (L === 'quad') {
      return '<div class="dg dg-quad">' + it.map(function (x, i) { return b(i, 'dg-pz p' + i + (x.hl ? ' hl' : ''), (x.icon ? '<span class="dg-ic">' + icl(x.icon) + '</span>' : '') + '<b>' + rich(x.title) + '</b>' + (x.sub ? '<small>' + esc(x.sub) + '</small>' : '')); }).join('') + '</div>';
    }
    if (L === 'hflow') {
      return '<div class="dg dg-hflow">' + it.map(function (x, i) { return (i ? '<span class="dg-lt" aria-hidden="true"></span>' : '') + b(i, 'dg-hf', '<small class="dg-stg">' + esc(x.stage || '') + '</small>' + (x.icon ? '<span class="dg-ic">' + icl(x.icon) + '</span>' : '') + '<b>' + rich(x.title) + '</b>' + (x.sub ? '<small>' + esc(x.sub) + '</small>' : '')); }).join('') + '</div>';
    }
    if (L === 'infinity') {
      var Q = [[78, 18], [78, 82], [22, 82], [22, 18]];
      return '<div class="dg dg-inf"><svg viewBox="0 0 600 400" aria-hidden="true">' + arrow +
        '<path d="M300 200 C 380 60 570 60 570 200 C 570 340 380 340 300 200 C 220 340 30 340 30 200 C 30 60 220 60 300 200" class="lp"/>' +
        '<polygon class="mk" points="552,188 588,188 570,216"/><polygon class="mk" points="448,290 448,322 420,306"/><polygon class="mk" points="12,212 48,212 30,184"/><polygon class="mk" points="152,78 152,110 180,94"/></svg>' +
        it.map(function (x, i) { return b(i, 'dg-o', '<b>' + rich(x.title) + '</b>', 'left:' + Q[i][0] + '%;top:' + Q[i][1] + '%'); }).join('') + '</div>';
    }
    if (L === 'rings') {
      return '<div class="dg dg-rings">' + it.map(function (x, i) { return '<div class="dg-r r' + i + '">' + b(i, 'dg-rl', '<b>' + rich(x.title) + '</b><small>' + esc(x.sub || '') + '</small>') + '</div>'; }).join('') + '</div>';
    }
    if (L === 'grid2') {
      return '<div class="dg dg-grid"><div class="dg-ax t">' + esc(s.axes[0]) + '</div><div class="dg-ax t2">' + esc(s.axes[1]) + '</div><div class="dg-ax s">' + esc(s.axes[2]) + '</div><div class="dg-ax s2">' + esc(s.axes[3]) + '</div><div class="dg-g">' +
        it.map(function (x, i) { return b(i, 'dg-q' + (x.hl ? ' hl' : ''), (x.icon ? '<span class="dg-ic">' + icl(x.icon) + '</span>' : '') + '<b>' + rich(x.title) + '</b>'); }).join('') + '</div></div>';
    }
    if (L === 'flow') {
      return '<div class="dg dg-flow">' + it.map(function (x, i) { return (i ? '<span class="dg-dn" aria-hidden="true"></span>' : '') + b(i, 'dg-f', '<b>' + rich(x.title) + '</b>'); }).join('') + '</div>';
    }
    if (L === 'podium') {
      return '<div class="dg dg-pod">' + it.map(function (x, i) { return '<div class="dg-pc"><div class="dg-pt"><b>' + esc(x.letter || '') + '</b><span>' + rich(x.title) + '</span></div>' + b(i, 'dg-pb', '<span class="dg-ic">' + icl(x.icon) + '</span><span>' + rich(x.title) + '</span>', 'height:' + (100 - i * 11) + '%') + '</div>'; }).join('') + '</div>';
    }
    if (L === 'arches') {
      return '<div class="dg dg-arch">' + it.map(function (x, i) { return b(i, 'dg-ar', '<span class="dg-ic">' + icl(x.icon) + '</span><b>' + rich(x.title) + '</b>'); }).join('') + '</div>';
    }
    if (L === 'pie') {
      return '<div class="dg dg-pie"><svg viewBox="0 0 640 360" aria-hidden="true"><circle cx="180" cy="180" r="150" class="pa"/><path d="M180 180 L180 30 A150 150 0 0 1 322.7 133.6 Z" class="pb"/>' +
        '<text x="234" y="118" class="pt2" text-anchor="middle">20%</text><text x="132" y="250" class="pt1" text-anchor="middle">80%</text>' +
        '<g class="sc"><path d="M500 60 L500 300 M440 300 L560 300 M410 110 L590 140"/><circle cx="500" cy="52" r="10"/><path d="M410 110 L380 190 L440 190 Z M590 140 L560 240 L620 240 Z" class="pans"/></g>' +
        '<rect x="388" y="168" width="44" height="28" rx="5" class="w1"/><rect x="552" y="200" width="76" height="46" rx="8" class="w2"/><text x="410" y="188" class="wt">20%</text><text x="590" y="230" class="wt2">80%</text></svg></div>';
    }
    return '';
  }
  R.model = function (s, c, a) {
    var n = s.items.length, open = {};
    c.innerHTML = '<div class="x-wrap x-mdl"><div class="fx x-dgw">' + dia(s, true) + '</div><div class="x-card fx x-dd2">' + (s.intro ? '<p class="x-lead">' + rich(s.intro) + '</p>' : '') + '<div class="x-dtx"><div class="x-ph">' + icl(s.phIcon || 'questions') + '<span>' + esc(s.hint || 'اضغط أي جزء في الرسم لتظهر تفاصيله هنا.') + '</span><small>' + T('found', 0, s.items.length) + '</small></div></div>' + (s.note ? '<div class="x-note">' + icl(s.noteIcon || 'guidance') + '<span>' + rich(s.note) + '</span></div>' : '') + '</div></div>';
    reveal(a, c);
    var g = gate(a, ['say', 'all']), D2 = q(c, '.x-dtx');
    qa(c, '.dg-n').forEach(function (bt) { bt.onclick = function (e) { e.stopPropagation(); var i = +bt.dataset.i, x = s.items[i]; open[i] = 1;
      qa(c, '.dg-n').forEach(function (z) { z.classList.toggle('on', z === bt); }); bt.classList.add('seen');
      D2.innerHTML = '<h2>' + (x.icon ? icl(x.icon) : '') + rich(x.title) + (x.sub ? ' <small>' + esc(x.sub) + '</small>' : '') + '</h2>' + paras(x.text);
      D2.insertAdjacentHTML('beforeend', '<div class="x-cnt2">' + T('found', Object.keys(open).length, n) + '</div>');
      if (Object.keys(open).length === n) g('all'); }; });
    say(a, s.id, [], function () { g('say'); });
  };

  /* ---------- content: text + optional image or light video ---------- */
  R.content = function (s, c, a) {
    c.innerHTML = '<div class="x-wrap x-split' + (s.image || s.video ? '' : ' x-solo') + '"><div class="x-card fx">' + (s.kicker ? '<div class="x-kick">' + esc(s.kicker) + '</div>' : '') + (s.heading ? '<h2>' + rich(s.heading) + '</h2>' : '') + paras(s.text) +
      (s.points ? '<ul class="x-pts">' + s.points.map(function (p) { return '<li>' + rich(p) + '</li>'; }).join('') + '</ul>' : '') + (s.note ? '<div class="x-note">' + icl(s.noteIcon || 'guidance') + '<span>' + rich(s.note) + '</span></div>' : '') + '</div>' + (media(s) ? '<div class="fx">' + media(s) + '</div>' : '') + '</div>';
    reveal(a, c); say(a, s.id, [], function () { a.complete(); });
  };

  /* ---------- cards: reveal on narration, or flip/open each ---------- */
  R.cards = function (s, c, a) {
    var flip = s.mode === 'flip', n = s.items.length;
    c.innerHTML = '<div class="x-wrap">' + (s.intro ? '<p class="x-lead fx">' + rich(s.intro) + '</p>' : '') + '<div class="x-cards x-n' + Math.min(n, 4) + '">' + s.items.map(function (it, i) {
      return '<button class="x-cd fx' + (flip ? ' fl' : '') + '" data-i="' + i + '"' + (flip ? '' : ' tabindex="-1"') + '><span class="x-ic">' + icl(it.icon || 'guidance') + '</span><b>' + rich(it.title) + '</b><span class="x-tx">' + rich(it.text || '') + '</span>' + (flip ? '<span class="x-tap">' + ico('eye') + '</span>' : '') + '</button>';
    }).join('') + '</div>' + (flip ? '<div class="x-hint fx">' + ico('hand') + T('selectAll') + '</div>' : '') + '</div>';
    reveal(a, c);
    var g = gate(a, flip ? ['say', 'all'] : ['say']), open = {};
    if (flip) qa(c, '.x-cd').forEach(function (b) { b.onclick = function () { b.classList.add('op'); open[b.dataset.i] = 1; if (Object.keys(open).length === n) g('all'); }; });
    say(a, s.id, [], function () { g('say'); });
  };

  /* ---------- steps: ordered process, one step at a time ---------- */
  R.steps = function (s, c, a) {
    var n = s.items.length, k = 0;
    c.innerHTML = '<div class="x-wrap">' + (s.intro ? '<p class="x-lead fx">' + rich(s.intro) + '</p>' : '') + '<div class="x-steps fx">' + s.items.map(function (it, i) { return '<button class="x-st' + (i ? '' : ' on') + '" data-i="' + i + '"><span class="x-no">' + (i + 1) + '</span><span>' + rich(it.title) + '</span></button>'; }).join('') + '</div><div class="x-sbody x-card fx"></div></div>';
    var B = q(c, '.x-sbody'), seen = {}, g = gate(a, ['say', 'all']);
    function show(i) { k = i; seen[i] = 1; qa(c, '.x-st').forEach(function (b, j) { b.classList.toggle('on', j === i); b.classList.toggle('dn', !!seen[j]); });
      var it = s.items[i]; B.innerHTML = '<div class="x-kick">' + T('steps', i + 1, n) + '</div><h2>' + (it.icon ? icl(it.icon) : '') + rich(it.title) + '</h2>' + paras(it.text) + (i < n - 1 ? '<button class="x-btn" id="x-nx">' + T('continueBtn') + ico('chevron-' + (window.LANG === 'ar' ? 'left' : 'right')) + '</button>' : '');
      var nx = q(c, '#x-nx'); if (nx) nx.onclick = function () { show(i + 1); }; if (Object.keys(seen).length === n) g('all'); }
    qa(c, '.x-st').forEach(function (b) { b.onclick = function () { show(+b.dataset.i); }; });
    reveal(a, c); show(0); say(a, s.id, [], function () { g('say'); });
  };


  /* ---------- sort: place each statement in its column ---------- */
  R.sort = function (s, c, a) {
    /* drag-and-drop (mouse, touch, pen) or tap-then-tap; any column is accepted, then «تحقّق» marks every card */
    var items = SHUF(s.items.length).map(function (i) { return s.items[i]; }), sel = null, checked = false, where = {};
    c.innerHTML = '<div class="x-wrap">' + (s.prompt ? '<p class="x-lead fx">' + rich(s.prompt) + '</p>' : '') + '<div class="x-hint fx">' + ico('hand') + T('sortHint') + '</div><div class="x-pool fx">' + items.map(function (it, i) { return '<button class="x-chip" data-i="' + i + '">' + rich(it.t) + '</button>'; }).join('') + '</div><div class="x-cols x-n' + s.cols.length + ' fx">' + s.cols.map(function (cl) { return '<div class="x-col" data-k="' + cl.key + '"><div class="x-ch">' + (cl.icon ? icl(cl.icon) : '') + esc(cl.label) + '</div><div class="x-drop"></div></div>'; }).join('') + '</div></div>';
    var g = gate(a, ['say', 'all']), pool = q(c, '.x-pool'), btn = document.createElement('div');
    btn.className = 'x-row x-srow'; btn.innerHTML = '<button class="x-btn" id="x-chk" disabled>' + ico('circle-check') + 'تحقّق من إجاباتك</button><span class="x-scnt"></span>';
    q(c, '.x-hint').after(btn);
    var colLabel = {}; (s.cols || []).forEach(function (cl) { colLabel[cl.key] = cl.label; });
    function count() { var n = Object.keys(where).length; q(c, '.x-scnt').textContent = n + ' / ' + items.length; q(c, '#x-chk').disabled = n < items.length || checked; }
    function place(ch, col) { if (checked) return; ch.classList.remove('sel'); if (col) { q(col, '.x-drop').appendChild(ch); where[ch.dataset.i] = col.dataset.k; } else { pool.appendChild(ch); delete where[ch.dataset.i]; } sel = null; count(); }
    qa(c, '.x-chip').forEach(function (b) {
      b.onclick = function () { if (checked || b.__drag) return; if (sel === b) { b.classList.remove('sel'); sel = null; return; }
        if (where[b.dataset.i] != null) { place(b, null); return; } qa(c, '.x-chip').forEach(function (x) { x.classList.remove('sel'); }); b.classList.add('sel'); sel = b; };
      b.addEventListener('pointerdown', function (e) { if (checked) return; var sx = e.clientX, sy = e.clientY, gh = null, mv = false;
        function move(ev) { var dx = ev.clientX - sx, dy = ev.clientY - sy; if (!mv && Math.abs(dx) + Math.abs(dy) < 8) return;
          if (!mv) { mv = true; b.__drag = true; gh = b.cloneNode(true); gh.className = 'x-chip x-ghost'; document.body.appendChild(gh); b.classList.add('drg'); }
          gh.style.left = ev.clientX + 'px'; gh.style.top = ev.clientY + 'px';
          qa(c, '.x-col').forEach(function (cl) { cl.classList.remove('ovr'); }); var t = document.elementFromPoint(ev.clientX, ev.clientY), cl = t && t.closest ? t.closest('.x-col') : null; if (cl) cl.classList.add('ovr'); }
        function up(ev) { document.removeEventListener('pointermove', move); document.removeEventListener('pointerup', up); document.removeEventListener('pointercancel', up);
          if (mv) { if (gh) gh.style.display = 'none'; var t = document.elementFromPoint(ev.clientX, ev.clientY), cl = t && t.closest ? t.closest('.x-col') : null, pl = t && t.closest ? t.closest('.x-pool') : null;
            if (cl) place(b, cl); else if (pl) place(b, null); if (gh) gh.remove(); b.classList.remove('drg'); qa(c, '.x-col').forEach(function (x) { x.classList.remove('ovr'); }); setTimeout(function () { b.__drag = false; }, 50); } }
        document.addEventListener('pointermove', move); document.addEventListener('pointerup', up); document.addEventListener('pointercancel', up); });
    });
    qa(c, '.x-col').forEach(function (col) { col.onclick = function (e) { if (e.target.closest('.x-chip')) return; if (sel) place(sel, col); }; });
    q(c, '#x-chk').onclick = function () { checked = true; var nOk = 0;
      qa(c, '.x-chip').forEach(function (ch) { var it = items[+ch.dataset.i], ok = where[ch.dataset.i] === it.col; if (ok) nOk++;
        ch.classList.add(ok ? 'ok' : 'no'); if (!ok) ch.insertAdjacentHTML('beforeend', '<em class="x-cor">' + ico('arrow-left') + esc(colLabel[it.col] || '') + '</em>'); });
      a.track({ id: code(s) + '_SORT' + s.id.split('-')[1], type: 'matching', desc: s.title || s.prompt || 'Sort', response: nOk + '/' + items.length, correct: items.length + '/' + items.length, result: nOk === items.length ? 'correct' : 'incorrect' });
      var h = q(c, '.x-hint'); h.innerHTML = ico('circle-check') + (nOk === items.length ? 'أحسنت! كل العبارات في مكانها الصحيح.' : 'صحيح ' + nOk + ' من ' + items.length + '. العبارات الحمراء يظهر بجوارها مكانها الصحيح.'); h.classList.add('ok');
      q(c, '#x-chk').disabled = true; g('all'); };
    count(); reveal(a, c); say(a, s.id, [], function () { g('say'); });
  };

  /* ---------- scenario: one decision with feedback for every option ---------- */
  R.scenario = function (s, c, a) {
    if (s.poll) return poll(s, c, a);
    var ord = SHUF(s.options.length), best = -1; s.options.forEach(function (o, i) { if (o.ok) best = i; });
    c.innerHTML = '<div class="x-wrap x-split x-sc"><div class="fx">' + media(s) + '</div><div class="x-card fx"><div class="x-kick">' + icl('investigation') + T('scenario') + '</div>' + (s.heading ? '<h2>' + rich(s.heading) + '</h2>' : '') + paras(s.situation) + '<h3>' + rich(s.question || T('whatDo')) + '</h3><div class="x-ops">' +
      ord.map(function (i, k) { return '<button class="x-op" data-i="' + i + '" disabled><span class="x-l">' + LT[k] + '</span><span>' + rich(s.options[i].t) + '</span></button>'; }).join('') + '</div><div class="x-fb" aria-live="polite"></div></div></div>';
    reveal(a, c);
    var O = qa(c, '.x-op'), done = false, t0 = Date.now();
    say(a, s.id, [], function () { O.forEach(function (b) { b.disabled = false; }); });
    if (a.isDone && a.isDone(s.id)) O.forEach(function (b) { b.disabled = false; });
    O.forEach(function (b) { b.onclick = function () {
      var i = +b.dataset.i, o = s.options[i], ok = !!o.ok; O.forEach(function (x) { x.disabled = true; x.classList.remove('w'); });
      var bb = O.filter(function (x) { return +x.dataset.i === best; })[0]; bb.classList.add('r'); if (!ok) b.classList.add('w');
      q(c, '.x-fb').className = 'x-fb show ' + (ok ? 'ok' : 'no'); q(c, '.x-fb').innerHTML = '<b>' + (ok ? T('correct') : T('notQuite') + ' ' + T('bestIs', LT[O.indexOf(bb)])) + '</b> ' + rich(o.fb || '') + (!ok && s.options[best].fb ? '<div class="x-why">' + rich(s.options[best].fb) + '</div>' : '') + (!ok && s.retry !== false ? '<button class="x-btn sm" id="x-re">' + T('tryAgain') + '</button>' : '');
      if (!done) { done = true; a.track({ id: code(s) + '_S' + s.id.split('-')[1], type: 'choice', desc: s.question || s.heading || s.title || 'Scenario', response: 'opt' + (i + 1), correct: 'opt' + (best + 1), result: ok ? 'correct' : 'incorrect', latencyMs: Date.now() - t0 }); a.complete(); }
      var re = q(c, '#x-re'); if (re) re.onclick = function () { O.forEach(function (x) { x.disabled = false; x.classList.remove('r', 'w'); }); q(c, '.x-fb').className = 'x-fb'; q(c, '.x-fb').innerHTML = ''; };
      say(a, s.id + '-F' + (i + 1), [], null);
    }; });
  };


  /* ---------- poll: a self-check question with no right answer (before/after comparison) ---------- */
  function poll(s, c, a) {
    var ord = SHUF(s.options.length), prev = s.compare ? a.persist('poll_' + s.compare) : null;
    c.innerHTML = '<div class="x-wrap x-split x-sc' + (media(s) ? '' : ' x-solo') + '">' + (media(s) ? '<div class="fx">' + media(s) + '</div>' : '') + '<div class="x-card fx"><div class="x-kick">' + icl('questions') + esc(s.kicker || 'استطلاع') + '</div>' + (s.heading ? '<h2>' + rich(s.heading) + '</h2>' : '') + paras(s.situation) + '<h3>' + rich(s.question) + '</h3><div class="x-ops">' +
      ord.map(function (i, k) { return '<button class="x-op" data-i="' + i + '" disabled><span class="x-l">' + LT[k] + '</span><span>' + rich(s.options[i].t) + '</span></button>'; }).join('') + '</div><div class="x-fb" aria-live="polite"></div></div></div>';
    reveal(a, c);
    var O = qa(c, '.x-op'), done = false, t0 = Date.now();
    say(a, s.id, [], function () { O.forEach(function (b) { b.disabled = false; }); });
    if (a.isDone && a.isDone(s.id)) O.forEach(function (b) { b.disabled = false; });
    O.forEach(function (b) { b.onclick = function () {
      var i = +b.dataset.i, o = s.options[i]; O.forEach(function (x) { x.disabled = true; x.classList.remove('pk'); }); b.classList.add('pk');
      a.persist('poll_' + s.pid, i);
      var cmp = (s.compare && prev != null && s.options[prev]) ? '<div class="x-why"><b>' + esc(s.compareLabel || 'اخترت في بداية الدرس:') + '</b> «' + rich(s.options[prev].t) + '» — ' + rich(s.options[prev].fb || '') + '</div>' : '';
      var f = q(c, '.x-fb'); f.className = 'x-fb show ' + (s.neutral ? '' : (o.good ? 'ok' : 'no')); f.innerHTML = rich(o.fb || '') + cmp + (s.note ? '<div class="x-why">' + rich(s.note) + '</div>' : '');
      if (!done) { done = true; a.track({ id: s.pid, type: 'choice', desc: s.question, response: 'opt' + (i + 1), result: 'neutral', latencyMs: Date.now() - t0 }); a.complete(); }
      say(a, s.id + '-F' + (i + 1), [], null);
    }; });
  }

  /* ---------- branch: a short branching scenario (2–4 decisions) ---------- */
  R.branch = function (s, c, a) {
    var path = [], score = 0;
    c.innerHTML = '<div class="x-wrap x-split x-sc"><div class="fx x-bimg">' + media(s) + '</div><div class="x-card fx x-br"></div></div>';
    reveal(a, c);
    var B = q(c, '.x-br'), g = gate(a, ['say', 'end']);
    function node(id) {
      var nd = s.nodes[id]; if (nd.image) q(c, '.x-bimg').innerHTML = '<div class="x-med"><img src="' + nd.image + '" alt=""></div>';
      if (!nd.options) { /* outcome */
        var lvl = nd.level || (score >= path.length * 2 ? 'good' : (score >= path.length ? 'ok' : 'risk'));
        B.innerHTML = '<div class="x-kick">' + T('outcome') + '</div><div class="x-out ' + lvl + '">' + icl(lvl === 'good' ? 'approval' : (lvl === 'ok' ? 'guidance' : 'hazard')) + '<h2>' + rich(nd.title || '') + '</h2></div>' + paras(nd.text) + '<button class="x-btn sm" id="x-rs">' + ico('rotate-left') + T('restart') + '</button>';
        a.track({ id: code(s) + '_B' + s.id.split('-')[1], type: 'other', desc: (s.title || 'Branching scenario') + ' — path', response: path.join('>').slice(0, 250), result: 'neutral' });
        q(c, '#x-rs').onclick = function () { path = []; score = 0; node(s.start || 'start'); }; g('end'); return;
      }
      var ord = SHUF(nd.options.length);
      B.innerHTML = '<div class="x-kick">' + icl('investigation') + T('decision', path.length + 1) + '</div>' + paras(nd.text) + '<h3>' + rich(nd.question || T('whatDo')) + '</h3><div class="x-ops">' + ord.map(function (i, k) { return '<button class="x-op" data-i="' + i + '"><span class="x-l">' + LT[k] + '</span><span>' + rich(nd.options[i].t) + '</span></button>'; }).join('') + '</div><div class="x-fb"></div>';
      qa(B, '.x-op').forEach(function (b) { b.onclick = function () {
        var o = nd.options[+b.dataset.i]; score += (o.score == null ? (o.ok ? 2 : 0) : o.score); path.push(id + ':' + (+b.dataset.i + 1));
        qa(B, '.x-op').forEach(function (x) { x.disabled = true; }); b.classList.add('pk');
        var f = q(B, '.x-fb'); f.className = 'x-fb show ' + ((o.score == null ? o.ok : o.score >= 2) ? 'ok' : 'no'); f.innerHTML = rich(o.fb || '') + '<button class="x-btn sm" id="x-go">' + T('continueBtn') + '</button>';
        q(B, '#x-go').onclick = function () { node(o.next); };
      }; });
    }
    node(s.start || 'start'); say(a, s.id, [], function () { g('say'); });
  };

  /* ---------- hotspot: find every point in a picture ---------- */
  R.hotspot = function (s, c, a) {
    var n = s.spots.length, got = {};
    c.innerHTML = '<div class="x-wrap x-split x-hs"><div class="fx x-pic"><img src="' + s.image + '" alt="">' + s.spots.map(function (p, i) { return '<button class="x-spot" data-i="' + i + '" style="left:' + p.x + '%;top:' + p.y + '%;width:' + (p.r || 10) + '%;height:' + (p.r || 10) * 1.78 + '%" aria-label="' + esc(p.label) + '"></button>'; }).join('') + '</div><div class="x-card fx">' + (s.prompt ? '<h3>' + rich(s.prompt) + '</h3>' : '') + '<div class="x-cnt">' + T('found', 0, n) + '</div><div class="x-list"></div></div></div>';
    reveal(a, c);
    var g = gate(a, ['say', 'all']);
    qa(c, '.x-spot').forEach(function (b) { b.onclick = function () {
      var i = b.dataset.i; if (got[i]) return; got[i] = 1; b.classList.add('ok'); b.innerHTML = '<span>' + Object.keys(got).length + '</span>';
      var p = s.spots[i]; q(c, '.x-list').insertAdjacentHTML('beforeend', '<div class="x-it"><span class="x-no">' + Object.keys(got).length + '</span><div><b>' + rich(p.label) + '</b>' + (p.fb ? '<p>' + rich(p.fb) + '</p>' : '') + '</div></div>');
      q(c, '.x-cnt').textContent = T('found', Object.keys(got).length, n);
      if (Object.keys(got).length === n) { a.track({ id: code(s) + '_H' + s.id.split('-')[1], type: 'other', desc: s.prompt || s.title || 'Hotspots', response: n + '/' + n, result: 'neutral' }); g('all'); }
    }; });
    say(a, s.id, [], function () { g('say'); });
  };

  /* ---------- video: a short video that reinforces the content ---------- */
  R.video = function (s, c, a) {
    c.innerHTML = '<div class="x-wrap x-vid"><div class="fx x-vbox"><video src="' + s.video + '"' + (s.poster ? ' poster="' + s.poster + '"' : '') + ' controls playsinline preload="metadata"></video></div>' + (s.text ? '<div class="x-card fx x-cap">' + paras(s.text) + '</div>' : '') + '</div>';
    reveal(a, c);
    var v = q(c, 'video'), g = gate(a, s.mustWatch === false ? ['say'] : ['say', 'end']);
    v.onended = function () { a.track({ id: code(s) + '_V' + s.id.split('-')[1], type: 'other', desc: (s.title || 'Video') + ' — watched', response: 'watched', result: 'neutral' }); g('end'); };
    v.onerror = function () { g('end'); };
    say(a, s.id, [], function () { g('say'); });
  };

  /* ---------- quiz: lesson knowledge check with pass mark and retake ---------- */
  R.quiz = function (s, c, a) {
    var Q = s.questions, pass = s.pass || D.passPct || 80, k = 0, right = 0, st = a.persist('q_' + s.id) || { att: 0 };
    function intro() {
      c.innerHTML = '<div class="x-wrap"><div class="x-card x-qi fx">' + icl('questions') + '<h2>' + (s.heading ? rich(s.heading) : T('kc')) + '</h2><p>' + T('qCount', Q.length) + '</p><p>' + T('passMark', pass) + '</p><button class="x-btn" id="x-qs">' + T('startBtn') + '</button></div></div>';
      reveal(a, c); q(c, '#x-qs').onclick = function () { st.att++; a.persist('q_' + s.id, st); k = 0; right = 0; ask(); };
      say(a, s.id, [], null);
    }
    function ask() {
      var it = Q[k], ord = SHUF(it.o.length);
      c.innerHTML = '<div class="x-wrap"><div class="x-card x-q fx in"><div class="x-kick">' + T('question', k + 1, Q.length) + '</div><h2>' + rich(it.q) + '</h2><div class="x-ops">' + ord.map(function (i, j) { return '<button class="x-op" data-i="' + i + '" data-k="' + j + '"><span class="x-l">' + LT[j] + '</span><span>' + rich(it.o[i]) + '</span></button>'; }).join('') + '</div><div class="x-fb"></div></div></div>';
      var O = qa(c, '.x-op'), t0 = Date.now();
      O.forEach(function (b) { b.onclick = function () {
        var i = +b.dataset.i, ok = i === it.a; if (ok) right++; O.forEach(function (x) { x.disabled = true; });
        var rb = O.filter(function (x) { return +x.dataset.i === it.a; })[0]; rb.classList.add('r'); if (!ok) b.classList.add('w');
        a.track({ id: code(s) + '_Q' + (k + 1), type: 'choice', desc: it.q, response: 'opt' + (i + 1), correct: 'opt' + (it.a + 1), result: ok ? 'correct' : 'incorrect', latencyMs: Date.now() - t0 });
        var f = q(c, '.x-fb'); f.className = 'x-fb show ' + (ok ? 'ok' : 'no'); f.innerHTML = '<b>' + (ok ? T('correct') : T('notQuite') + ' ' + T('correctIs', LT[+rb.dataset.k])) + '</b> ' + rich(it.fb || '') + '<button class="x-btn sm" id="x-qn">' + T('continueBtn') + '</button>';
        q(c, '#x-qn').onclick = function () { k++; if (k < Q.length) ask(); else result(); };
      }; });
    }
    function result() {
      var pct = Math.round(right / Q.length * 100), ok = pct >= pass;
      c.innerHTML = '<div class="x-wrap"><div class="x-card x-qr fx in ' + (ok ? 'ok' : 'no') + '"><div class="x-ring"><b>' + pct + '%</b><span>' + T('yourScore') + '</span></div><h2>' + (ok ? T('passed') : T('notPassed')) + '</h2><p>' + T('passMark', pass) + '</p>' + (ok ? '' : '<button class="x-btn" id="x-rt">' + ico('rotate-left') + T('retake') + '</button>') + '</div></div>';
      a.lessonResult(s.lesson.code, pct); if (ok) a.complete();
      var rt = q(c, '#x-rt'); if (rt) rt.onclick = function () { st.att++; a.persist('q_' + s.id, st); k = 0; right = 0; ask(); };
    }
    intro();
  };

  /* ---------- reflection: questions with choices + Other ---------- */
  function optsFor(it, vals) { if (it.from != null && it.map) { var pv = vals[it.from]; if (pv && it.map[pv]) return it.map[pv]; return it.options || []; } return it.options || []; }
  R.reflection = function (s, c, a) {
    var saved = a.persist('r_' + s.id) || {};
    c.innerHTML = '<div class="x-wrap"><div class="x-card fx">' + (s.intro ? '<p class="x-lead">' + rich(s.intro) + '</p>' : '') + '<div class="x-rf">' + s.items.map(function (it, i) {
      var v = saved[i] || '', ops = optsFor(it, saved), isO = v && ops.indexOf(v) < 0;
      return '<div class="x-ri"><label>' + (i + 1) + '. ' + rich(it.q) + '</label><select data-i="' + i + '"><option value="">—</option>' + ops.map(function (o) { return '<option' + (o === v ? ' selected' : '') + '>' + esc(o) + '</option>'; }).join('') + '<option value="__o"' + (isO ? ' selected' : '') + '>' + T('other') + '</option></select><input type="text" data-i="' + i + '" placeholder="' + T('write') + '" value="' + (isO ? esc(v) : '') + '"' + (isO ? '' : ' hidden') + '></div>';
    }).join('') + '</div><div class="x-pbox" hidden></div><div class="x-row"><button class="x-btn" id="x-sv">' + (s.build ? (s.build.btn || 'اجمع أمري') : T('saveRefl')) + '</button><span class="x-ok" id="x-ok"></span>' + (s.print !== false ? '<button class="x-btn ghost" id="x-pr" hidden>' + icl('documents') + T('print') + '</button>' : '') + '</div></div></div>';
    reveal(a, c);
    var g = gate(a, ['say', 'saved']);
    function val(i) { var sel = q(c, 'select[data-i="' + i + '"]'), inp = q(c, 'input[data-i="' + i + '"]'); return sel.value === '__o' ? inp.value.trim() : sel.value; }
    function refill(j) { var it = s.items[j], vals = {}; s.items.forEach(function (x, k) { vals[k] = val(k); });
      var sel = q(c, 'select[data-i="' + j + '"]'), ops = optsFor(it, vals);
      sel.innerHTML = '<option value="">—</option>' + ops.map(function (o) { return '<option>' + esc(o) + '</option>'; }).join('') + '<option value="__o">' + T('other') + '</option>';
      q(c, 'input[data-i="' + j + '"]').hidden = true; }
    qa(c, 'select').forEach(function (sel) { sel.onchange = function () { q(c, 'input[data-i="' + sel.dataset.i + '"]').hidden = sel.value !== '__o';
      s.items.forEach(function (it, j) { if (it.from === +sel.dataset.i) refill(j); }); }; });
    q(c, '#x-sv').onclick = function () {
      var all = s.items.map(function (x, i) { return val(i); }); if (all.some(function (v) { return !v; })) return;
      var S = {}; all.forEach(function (v, i) { S[i] = v; a.track({ id: code(s) + '_R' + s.id.split('-')[1] + '_' + (i + 1), type: 'fill-in', desc: s.items[i].q, response: v.slice(0, 250), result: 'neutral' }); });
      a.persist('r_' + s.id, S); q(c, '#x-ok').innerHTML = ico('circle-check') + T('saved'); var pr = q(c, '#x-pr'); if (pr) pr.hidden = false; g('saved'); showP(S);
    };
    /* "build your prompt": the choices assembled into one ready prompt */
    function showP(S) { if (!s.build) return; var bx = q(c, '.x-pbox'), txt = (s.build.lead ? s.build.lead + '\n' : '') + s.items.map(function (it, i) { return it.pre ? it.pre + ' ' + (S[i] || '') : null; }).filter(Boolean).join('\n');
      bx.hidden = false; bx.innerHTML = '<div class="x-ph2">' + icl('ai') + '<b>' + esc(s.build.title || 'أمرك جاهز') + '</b><button class="x-btn ghost" id="x-cp">' + icl('documents') + 'انسخ الأمر</button></div><pre class="x-ptx">' + esc(txt) + '</pre>';
      q(c, '#x-cp').onclick = function () { var r = document.createRange(); r.selectNodeContents(q(c, '.x-ptx')); var sl = window.getSelection(); sl.removeAllRanges(); sl.addRange(r);
        try { (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).catch(function () { document.execCommand('copy'); }); } catch (e) { document.execCommand('copy'); } q(c, '#x-cp').innerHTML = ico('circle-check') + 'تم النسخ'; }; }
    if (Object.keys(saved).length) showP(saved);
    var pr = q(c, '#x-pr'); if (pr) { if (Object.keys(saved).length) { pr.hidden = false; g('saved'); }
      pr.onclick = function () { var S = a.persist('r_' + s.id) || {}; var rows = s.items.map(function (it, i) { return '<div class="q"><b>' + (i + 1) + '. ' + esc(it.q) + '</b><p>' + esc(S[i] || '—') + '</p></div>'; }).join('');
        var html = '<html dir="' + document.documentElement.dir + '"><head><meta charset="utf-8"><title>' + T('reflect') + '</title><style>body{font-family:Almarai,Arial,sans-serif;margin:40px;color:#1d2b3a}h1{font-size:22px}.s{color:#667;font-size:13px;margin-bottom:20px}.q{border-inline-start:4px solid #888;padding:6px 14px;margin:0 0 14px}.q p{margin:6px 0 0}</style></head><body><h1>' + esc(s.title || T('reflect')) + '</h1><div class="s">' + esc(D.title) + ' · ' + new Date().toLocaleDateString(window.LANG === 'ar' ? 'ar-SA' : 'en-GB') + '</div>' + rows + '</body></html>';
        var txt = s.items.map(function (it, i) { return (i + 1) + '. ' + it.q + '\n' + (S[i] || '—'); }).join('\n\n');
        var box = q(c, '.x-pfb'); if (!box) { box = document.createElement('div'); box.className = 'x-pfb'; q(c, '.x-row').after(box); }
        box.innerHTML = '<span>إن لم تظهر نافذة الطباعة:</span><button class="x-btn ghost" id="x-dl">' + icl('documents') + 'نزّل تأملي ملفاً</button><button class="x-btn ghost" id="x-cpy">' + icl('documents') + 'انسخ النص</button>';
        q(box, '#x-dl').onclick = function () { try { var bl = new Blob(['\ufeff' + html], { type: 'text/html;charset=utf-8' }), u = URL.createObjectURL(bl), l = document.createElement('a'); l.href = u; l.download = (s.title || 'reflection') + '.html'; document.body.appendChild(l); l.click(); setTimeout(function () { URL.revokeObjectURL(u); l.remove(); }, 2000); } catch (err) { } };
        q(box, '#x-cpy').onclick = function () { var ta = document.createElement('textarea'); ta.value = txt; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); try { (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).catch(function () { document.execCommand('copy'); }); } catch (err) { document.execCommand('copy'); } ta.remove(); q(box, '#x-cpy').innerHTML = ico('circle-check') + 'تم النسخ'; };
        var f = document.createElement('iframe'); f.style.cssText = 'position:fixed;width:0;height:0;border:0'; document.body.appendChild(f); var w = f.contentWindow; w.document.open(); w.document.write(html); w.document.close(); setTimeout(function () { try { w.focus(); w.print(); } catch (e) { } setTimeout(function () { f.remove(); }, 1500); }, 250); }; }
    say(a, s.id, [], function () { g('say'); });
  };

  /* ---------- acknowledgment ---------- */
  R.ack = function (s, c, a) {
    var done = a.persist('a_' + s.id);
    c.innerHTML = '<div class="x-wrap"><div class="x-card x-ak fx"><span class="x-ic">' + icl('acknowledgment') + '</span><div><div class="x-kick">' + T('ackTitle') + '</div><label class="x-cb"><input type="checkbox" id="x-ac"' + (done ? ' checked disabled' : '') + '><span>' + rich(s.text) + '</span></label><button class="x-btn" id="x-ab"' + (done ? ' hidden' : ' disabled') + '>' + T('ackBtn') + '</button><span class="x-ok">' + (done ? ico('circle-check') + T('ackDone') : '') + '</span></div></div></div>';
    reveal(a, c);
    var cb = q(c, '#x-ac'), bt = q(c, '#x-ab');
    cb.onchange = function () { bt.disabled = !cb.checked; };
    bt.onclick = function () { a.persist('a_' + s.id, 1); cb.disabled = true; bt.hidden = true; q(c, '.x-ok').innerHTML = ico('circle-check') + T('ackDone');
      a.track({ id: code(s) + '_ACK', type: 'other', desc: s.text, response: 'acknowledged', result: 'neutral' }); a.complete(); };
    if (done) a.complete();
    say(a, s.id, [], null);
  };

  /* ---------- register lesson screens ---------- */
  (D.intro || []).forEach(function (s) { if (R[s.type]) E.register(s.id, { title: s.title, render: function (c, a) { c.className = 'x-scr x-' + s.type; R[s.type](s, c, a); } }); });
  (D.lessons || []).forEach(function (l) { l.screens.forEach(function (s) { if (R[s.type]) E.register(s.id, { title: s.title, render: function (c, a) { c.className = 'x-scr x-' + s.type; R[s.type](s, c, a); } }); }); });

  /* ---------- start ---------- */
  var CV = D.cover || {};
  E.register('S0', { title: T('start'), render: function (c, a) {
    c.innerHTML = '<div class="x-start">' + (CV.image ? '<img class="x-sbg" src="' + CV.image + '" alt="">' : '') + '<div class="x-sov"></div><img class="x-slogo" src="' + (D.logoLight || D.logo || 'assets/img/logo.png') + '" alt=""><div class="x-stx">' + (CV.kicker ? '<div class="x-kick">' + esc(CV.kicker) + '</div>' : '') + '<h1>' + esc(D.title) + '</h1>' + (CV.subtitle ? '<p>' + esc(CV.subtitle) + '</p>' : '') + '<button class="x-btn big" id="go-start">' + T('startBtn') + ico('chevron-' + (window.LANG === 'ar' ? 'left' : 'right')) + '</button></div>' + (D.sloganLight ? '<img class="x-slg" src="' + D.sloganLight + '" alt="وسّع نجاحك">' : '') + '</div>';
    q(c, '#go-start').onclick = function () { a.complete(); a.go(window.ENGINE.resumeTo || window.ENGINE.ORDER[1]); window.ENGINE.resumeTo = null; };
  } });
  /* ---------- What You Will Learn ---------- */
  E.register('S1', { title: T('wywl'), render: function (c, a) {
    var L = D.lessons || [], tot = 0; L.forEach(function (l) { tot += l.minutes || 0; }); if (D.exam) tot += D.exam.minutes || 0; if (D.pre) tot += D.pre.minutes || 0;
    c.innerHTML = '<div class="x-wrap x-obj"><div class="x-card fx"><div class="x-h">' + T('byEnd') + '</div>' + (D.objectives || []).map(function (o, k) { return '<div class="x-or"><span class="x-on">0' + (k + 1) + '</span><span class="x-ob"></span><span>' + rich(o) + '</span></div>'; }).join('') + (D.question ? '<div class="x-qq">' + icl('questions') + '<span>' + T('answers') + ' <b>' + esc(D.question) + '</b></span></div>' : '') + '</div>' +
      '<div class="x-map fx"><h4>' + T('map') + '</h4><div class="x-sb">' + L.length + ' · ' + T('approx') + ' ' + tot + ' ' + T('min') + '</div>' + (D.pre ? '<div class="x-mp"><span class="x-no">' + icl('questions') + '</span><span>' + esc(D.pre.title) + '</span><span class="x-d">' + (D.pre.minutes || '') + ' ' + T('min1') + '</span></div>' : '') + L.map(function (l, k) { return '<div class="x-mp"><span class="x-no">' + (k + 1) + '</span><span>' + esc(l.title) + '</span><span class="x-d">' + (l.minutes || '') + ' ' + T('min1') + '</span></div>'; }).join('') + (D.exam ? '<div class="x-mp"><span class="x-no">' + icl('questions') + '</span><span>' + esc(D.exam.title || T('exam')) + '</span><span class="x-d">' + (D.exam.minutes || '') + ' ' + T('min1') + '</span></div>' : '') + '<div class="x-tot"><span>' + T('total') + '</span><span>≈ ' + tot + ' ' + T('min') + '</span></div></div></div>';
    reveal(a, c); say(a, 'S1', [], function () { a.complete(); });
  } });
  var LTR = ['A', 'B', 'C', 'D', 'E', 'F'];
  /* ---------- pre-assessment: one attempt, diagnostic only (PRE_Q1..n) ---------- */
  if (D.pre) E.register('PR', { title: D.pre.title, render: function (c, a) {
    var P = D.pre, Q = P.questions, st = a.persist('pre') || {}, k = 0, right = 0;
    function intro() {
      c.innerHTML = '<div class="x-wrap"><div class="x-card x-qi fx in">' + icl('questions') + '<h2>' + esc(P.title) + '</h2>' + paras(P.intro) + '<p>' + T('qCount', Q.length) + '</p><button class="x-btn" id="x-ps">' + esc(P.startLabel || T('startBtn')) + '</button></div></div>';
      q(c, '#x-ps').onclick = function () { k = 0; right = 0; ask(); }; say(a, 'PR', [], null);
    }
    function ask() {
      var it = Q[k], ord = SHUF(it.o.length), t0 = Date.now();
      c.innerHTML = '<div class="x-wrap"><div class="x-card x-q fx in"><div class="x-kick">' + T('question', k + 1, Q.length) + '</div><h2>' + rich(it.q) + '</h2><div class="x-ops">' + ord.map(function (i, j) { return '<button class="x-op" data-i="' + i + '"><span class="x-l">' + LT[j] + '</span><span>' + rich(it.o[i]) + '</span></button>'; }).join('') + '</div></div></div>';
      qa(c, '.x-op').forEach(function (b) { b.onclick = function () {
        var i = +b.dataset.i, ok = i === it.a; if (ok) right++;
        a.track({ id: 'PRE_Q' + (k + 1), type: 'choice', desc: it.q, response: LTR[i], correct: LTR[it.a], result: ok ? 'correct' : 'incorrect', latencyMs: Date.now() - t0 });
        k++; if (k < Q.length) ask(); else done();
      }; });
    }
    function done() { st = { done: 1, pct: Math.round(right / Q.length * 100) }; a.persist('pre', st); a.complete(); result(); }
    function result() {
      c.innerHTML = '<div class="x-wrap"><div class="x-card x-qr fx in ok"><div class="x-ring"><b>' + st.pct + '%</b><span>' + T('yourScore') + '</span></div><h2>' + esc(P.doneTitle || '') + '</h2>' + paras(P.doneText) + '</div></div>';
      a.complete();
    }
    if (st.done) result(); else intro();
  } });
  /* ---------- post-assessment: one question per group (POST_Q1..n).
     First attempt: the source question of each group; retakes: a random question from each group ---------- */
  if (D.exam) E.register('EX', { title: D.exam.title || T('exam'), render: function (c, a) {
    var X = D.exam, bank = X.bank, G = {}, gs = [], pass = X.pass || D.passPct || 80, set = [], k = 0, right = 0;
    bank.forEach(function (b, i) { if (!G[b.g]) { G[b.g] = []; gs.push(b.g); } G[b.g].push(i); });
    var nDraw = gs.length;
    function intro() { c.innerHTML = '<div class="x-wrap"><div class="x-card x-qi fx in">' + icl('questions') + '<h2>' + esc(X.title || T('exam')) + '</h2><p>' + T('examIntro', nDraw, pass) + '</p><button class="x-btn" id="x-es">' + T('startExam') + '</button></div></div>';
      q(c, '#x-es').onclick = function () {
        var att = a.persist('exAtt') || 0; a.persist('exAtt', att + 1);
        set = gs.map(function (g) { var ids = G[g], src = ids.filter(function (i) { return bank[i].src; }); return (att === 0 && src.length) ? src[0] : ids[Math.floor(Math.random() * ids.length)]; });
        var o = SHUF(set.length); set = o.map(function (i) { return set[i]; }); k = 0; right = 0; ask(); }; say(a, 'EX', [], null); }
    function ask() { var it = bank[set[k]], ord = SHUF(it.o.length), t0 = Date.now();
      c.innerHTML = '<div class="x-wrap"><div class="x-card x-q fx in"><div class="x-kick">' + T('question', k + 1, nDraw) + '</div>' + (it.h ? '<div class="x-kick">' + esc(it.h) + '</div>' : '') + (it.s ? paras(it.s) : '') + '<h2>' + rich(it.q) + '</h2><div class="x-ops">' + ord.map(function (i, j) { return '<button class="x-op" data-i="' + i + '"><span class="x-l">' + LT[j] + '</span><span>' + rich(it.o[i]) + '</span></button>'; }).join('') + '</div></div></div>';
      qa(c, '.x-op').forEach(function (b) { b.onclick = function () { var i = +b.dataset.i, ok = i === it.a; if (ok) right++;
        a.track({ id: 'POST_Q' + (k + 1), type: 'choice', desc: (it.h ? it.h + ' — ' : '') + it.q, response: LTR[i], correct: LTR[it.a], result: ok ? 'correct' : 'incorrect', latencyMs: Date.now() - t0 });
        k++; if (k < nDraw) ask(); else result(); }; }); }
    function result() { var pct = Math.round(right / nDraw * 100), ok = pct >= pass; a.state.kc = a.state.kc || {}; a.quizResult(pct / 100, ok); if (ok) a.complete();
      c.innerHTML = '<div class="x-wrap"><div class="x-card x-qr fx in ' + (ok ? 'ok' : 'no') + '"><div class="x-ring"><b>' + pct + '%</b><span>' + T('yourScore') + '</span></div><h2>' + (ok ? T('passed') : T('notPassed')) + '</h2><p>' + T('passMark', pass) + '</p>' + (ok ? '' : '<p class="x-lockn">' + ico('lock') + 'تُفتح شاشة «اكتمل البرنامج» بعد اجتياز الاختبار بنسبة ' + pass + '% أو أكثر.</p><button class="x-btn" id="x-er">' + ico('rotate-left') + T('retake') + '</button>') + '</div></div>';
      var er = q(c, '#x-er'); if (er) er.onclick = intro; }
    intro();
  } });
  /* ---------- completion ---------- */
  var X = D.close || {};
  E.register('S9', { title: D.journey ? T('stationComplete', D.journey.current) : T('courseDone'), render: function (c, a) {
    var nx = X.next;
    c.innerHTML = '<div class="x-wrap x-end"><div class="x-card fx"><span class="x-tag">' + ico('circle-check') + esc(X.tag || T('doneTag')) + '</span><h3>' + T('achieved') + '</h3>' + (X.done || []).map(function (d) { return '<div class="x-dd"><span class="x-ic">' + icl(d[0]) + '</span><p>' + rich(d[1]) + '</p></div>'; }).join('') + (D.slogan ? '<img class="x-slg2" src="' + D.slogan + '" alt="وسّع نجاحك">' : '') + '</div>' +
      (nx ? '<div class="x-next fx"><div class="x-k">' + T('nextStep') + '</div><div class="x-big"><span class="x-nb">' + (nx.n ? nx.n : icl(nx.icon || 'fit-check')) + '</span><span class="x-nm">' + esc(nx.name) + '</span></div>' + (nx.q ? '<div class="x-nq">“' + esc(nx.q) + '”</div>' : (nx.sub ? '<div class="x-nq s">' + esc(nx.sub) + '</div>' : '')) + (nx.how || []).map(function (h) { return '<div class="x-hw">' + ico('chevron-' + (window.LANG === 'ar' ? 'left' : 'right')) + '<span>' + esc(h) + '</span></div>'; }).join('') + '</div>' : '') + '</div>';
    reveal(a, c); a.complete(); say(a, 'S9', [], null);
  } });
  E.start();
})();
