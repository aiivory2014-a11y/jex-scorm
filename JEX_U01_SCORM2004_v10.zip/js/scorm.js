/* SCORM 2004 4th Edition runtime wrapper (API_1484_11).
   - 2004-native data model (cmi.location, cmi.completion_status, cmi.success_status, cmi.score.*, cmi.exit, cmi.session_time).
   - Falls back to a SCORM 1.2 API (window.API) by mapping 2004 keys to 1.2 keys, so the same content still runs in a 1.2 LMS.
   - Falls back to in-memory mode (no browser storage) when no LMS is present. */
(function(){
  var api=null, ver=null, live=false, ended=false, mem={}, t0=Date.now();
  var cs="unknown", ss="unknown", objIdx=null, objCount=0, hooks=[], ixNext=null, ixFloor=0; // tracked for the 1.2 lesson_status mapping

  function findIn(w,name){
    var n=0;
    try{
      while(w&&!w[name]&&w.parent&&w.parent!==w&&n<500){w=w.parent;n++}
      return w&&w[name]?w[name]:null;
    }catch(e){return null}
  }
  function discover(name){
    var a=findIn(window,name);
    if(!a){try{if(window.opener)a=findIn(window.opener,name)}catch(e){}}
    if(!a){try{if(window.top&&window.top.opener)a=findIn(window.top.opener,name)}catch(e){}}
    return a;
  }
  api=discover("API_1484_11");
  if(api)ver="2004"; else {api=discover("API"); if(api)ver="1.2";}

  function ok(r){return r===true||r==="true"}
  function lastErr(){try{return ver==="2004"?String(api.GetLastError()):String(api.LMSGetLastError())}catch(e){return "?"}}
  function warn(op,k){try{console.warn("SCORM "+ver+" "+op+(k?" ["+k+"]":"")+" failed, error "+lastErr())}catch(e){}}

  /* ISO 8601 duration for 2004, HHHH:MM:SS.SS for 1.2 */
  function dur2004(ms){var s=ms/1000,h=Math.floor(s/3600),m=Math.floor(s%3600/60),sec=(s%60).toFixed(2);return "PT"+h+"H"+m+"M"+sec+"S"}
  function dur12(ms){var s=ms/1000,h=Math.floor(s/3600),m=Math.floor(s%3600/60),sec=s%60;function p(n,w){n=String(n);while(n.length<w)n="0"+n;return n}
    var si=Math.floor(sec),cc=Math.round((sec-si)*100);if(cc===100){cc=99}return p(h,4)+":"+p(m,2)+":"+p(si,2)+"."+p(cc,2)}

  function rawGet(k){
    try{var v=ver==="2004"?api.GetValue(k):api.LMSGetValue(k);return v==null?"":String(v)}catch(e){return ""}
  }
  function rawSet(k,v){
    var r;try{r=ver==="2004"?api.SetValue(k,String(v)):api.LMSSetValue(k,String(v))}catch(e){r=false}
    if(!ok(r))warn("SetValue",k);
    return ok(r);
  }
  function lesson12(){return (ss==="passed"||ss==="failed")?ss:(cs==="completed"?"completed":"incomplete")}

  /* 2004 key -> 1.2 key (null = no 1.2 equivalent, ignored) */
  var MAP12={
    "cmi.location":"cmi.core.lesson_location","cmi.suspend_data":"cmi.suspend_data",
    "cmi.score.raw":"cmi.core.score.raw","cmi.score.min":"cmi.core.score.min","cmi.score.max":"cmi.core.score.max",
    "cmi.score.scaled":null,"cmi.progress_measure":null,"cmi.entry":"cmi.core.entry",
    "cmi.learner_name":"cmi.core.student_name","cmi.learner_id":"cmi.core.student_id"
  };

  window.SCORM={
    version:function(){return live?ver:null},
    live:function(){return live},
    /* max characters the LMS must accept in cmi.suspend_data */
    maxSuspend:function(){return !live?Infinity:(ver==="2004"?64000:4096)},
    init:function(){
      if(live||!api)return live;
      if(ver==="2004"){
        live=ok(api.Initialize(""));
        if(!live&&lastErr()==="103")live=true; // already initialized
        if(!live){warn("Initialize");return false}
        cs=rawGet("cmi.completion_status")||"unknown";
        ss=rawGet("cmi.success_status")||"unknown";
        if(cs==="unknown"||cs==="not attempted"){rawSet("cmi.completion_status","incomplete");cs="incomplete"}
        rawSet("cmi.exit","suspend"); // keep the attempt open so progress and status resume on relaunch
      }else{
        live=ok(api.LMSInitialize(""));
        if(!live){warn("LMSInitialize");return false}
        var st=rawGet("cmi.core.lesson_status");
        if(st==="passed"||st==="failed"){ss=st;cs="completed"}else if(st==="completed"){cs="completed"}
        if(st===""||st==="not attempted"){rawSet("cmi.core.lesson_status","incomplete");cs="incomplete"}
        rawSet("cmi.core.exit","suspend");
      }
      this.commit();
      return live;
    },
    get:function(k){
      if(!live)return mem[k]||"";
      if(ver==="2004")return rawGet(k);
      if(k==="cmi.completion_status")return cs;
      if(k==="cmi.success_status")return ss;
      if(k==="cmi.learner_preference.audio_level"){var a=rawGet("cmi.student_preference.audio");return a==="-1"?"0":(a===""||a==="0"?"":"1")}
      if(k==="cmi.scaled_passing_score"){var m=rawGet("cmi.student_data.mastery_score");return m===""?"":String(parseFloat(m)/100)}
      var k12=MAP12.hasOwnProperty(k)?MAP12[k]:k;
      return k12?rawGet(k12):"";
    },
    set:function(k,v){
      if(!live){mem[k]=String(v);return true}
      if(ver==="2004"){
        if(k==="cmi.completion_status")cs=String(v);
        if(k==="cmi.success_status")ss=String(v);
        return rawSet(k,v);
      }
      if(k==="cmi.completion_status"){cs=String(v);return rawSet("cmi.core.lesson_status",lesson12())}
      if(k==="cmi.success_status"){ss=String(v);return rawSet("cmi.core.lesson_status",lesson12())}
      if(k==="cmi.exit")return rawSet("cmi.core.exit",v==="suspend"?"suspend":"");
      if(k==="cmi.learner_preference.audio_level")return rawSet("cmi.student_preference.audio",parseFloat(v)>0?"100":"-1");
      var k12=MAP12.hasOwnProperty(k)?MAP12[k]:k;
      return k12?rawSet(k12,v):true;
    },
    /* passing threshold as a 0..1 fraction: LMS value (cmi.scaled_passing_score) if supplied, else the given default */
    passMark:function(def){var p=parseFloat(this.get("cmi.scaled_passing_score"));return isNaN(p)?def:p},
    /* record one learner attempt in cmi.interactions (appended at the next free index — a journal, so repeated
       attempts at the same item each get their own record).
       o = {id, type:"choice"|"matching"|"other", desc, objective, correct, response, result:"correct"|"incorrect"|"neutral", weight, latencyMs}
       matching patterns use the 2004 delimiters "a[.]b[,]c[.]d"; they are converted for SCORM 1.2 automatically. */
    interaction:function(o){
      if(!live){(mem.interactions=mem.interactions||[]).push(o);return true}
      /* next free index: some LMSs do not update cmi.interactions._count during a session, so the index is kept
         locally (never lower than the LMS count or the count saved in suspend_data) to avoid overwriting record 0 */
      if(ixNext==null){var lc=parseInt(this.get("cmi.interactions._count"),10);ixNext=Math.max(isNaN(lc)?0:lc,ixFloor)}
      var n=ixNext++;
      var b="cmi.interactions."+n+".", d=new Date(), type=o.type||"choice";
      function v12(x){return String(x).replace(/\[\.\]/g,".").replace(/\[,\]/g,",")}
      if(ver==="2004"){
        rawSet(b+"id",o.id); rawSet(b+"type",type);
        if(o.objective)rawSet(b+"objectives.0.id",o.objective);
        if(o.desc)rawSet(b+"description",String(o.desc).slice(0,250));
        rawSet(b+"timestamp",d.toISOString().slice(0,22)+"Z");
        if(o.weight!=null)rawSet(b+"weighting",String(o.weight));
        if(o.correct!=null)rawSet(b+"correct_responses.0.pattern",o.correct);
        if(o.response!=null)rawSet(b+"learner_response",o.response);
        rawSet(b+"result",o.result);
        if(o.latencyMs!=null)rawSet(b+"latency",dur2004(o.latencyMs));
      }else{
        function p2(x){return (x<10?"0":"")+x}
        rawSet(b+"id",o.id); rawSet(b+"type",type==="other"?"performance":type);
        if(o.objective)rawSet(b+"objectives.0.id",o.objective);
        rawSet(b+"time",p2(d.getHours())+":"+p2(d.getMinutes())+":"+p2(d.getSeconds()));
        if(o.weight!=null)rawSet(b+"weighting",String(o.weight));
        if(o.correct!=null)rawSet(b+"correct_responses.0.pattern",v12(o.correct));
        if(o.response!=null)rawSet(b+"student_response",v12(o.response).slice(0,255));
        rawSet(b+"result",o.result==="incorrect"?"wrong":o.result);
        if(o.latencyMs!=null)rawSet(b+"latency",dur12(o.latencyMs).replace(/\.\d+$/,""));
      }
      this.commit();
      return true;
    },
    /* create or update a named objective (cmi.objectives) — one per lesson.
       o = {desc, raw, min, max, scaled, success:"passed"|"failed"|"unknown",
            completion:"completed"|"incomplete"|"not attempted", progress} ; fields left undefined are not written */
    objective:function(id,o){
      if(!live){(mem.objectives=mem.objectives||{})[id]=o;return true}
      if(!objIdx){objIdx={};var c=parseInt(this.get("cmi.objectives._count"),10),i;if(isNaN(c))c=0;objCount=c;
        for(i=0;i<c;i++)objIdx[this.get("cmi.objectives."+i+".id")]=i}
      var n=objIdx.hasOwnProperty(id)?objIdx[id]:-1;
      if(n<0){n=objCount;if(!rawSet("cmi.objectives."+n+".id",id))return false;objIdx[id]=n;objCount++}
      var b="cmi.objectives."+n+".";
      if(o.min!=null)rawSet(b+"score.min",o.min);
      if(o.max!=null)rawSet(b+"score.max",o.max);
      if(o.raw!=null)rawSet(b+"score.raw",o.raw);
      if(ver==="2004"){
        if(o.scaled!=null)rawSet(b+"score.scaled",o.scaled);
        if(o.success)rawSet(b+"success_status",o.success);
        if(o.completion)rawSet(b+"completion_status",o.completion);
        if(o.progress!=null)rawSet(b+"progress_measure",Math.max(0,Math.min(1,o.progress)).toFixed(2));
        if(o.desc)rawSet(b+"description",String(o.desc).slice(0,250));
      }else if(o.success||o.completion){
        rawSet(b+"status",(o.success==="passed"||o.success==="failed")?o.success:(o.completion==="completed"?"completed":(o.completion==="not attempted"?"not attempted":"incomplete")));
      }
      return true;
    },
    /* number of interaction records written so far, and a floor restored from suspend_data on relaunch */
    interactionCount:function(){return ixNext==null?ixFloor:ixNext},
    interactionFloor:function(k){k=parseInt(k,10);if(!isNaN(k)){ixFloor=Math.max(ixFloor,k);if(ixNext!=null)ixNext=Math.max(ixNext,ixFloor)}},
    /* functions to run just before the session is closed (e.g. to flush lesson time) */
    beforeFinish:function(fn){hooks.push(fn)},
    /* fraction of the course completed, 0..1 (2004 only) */
    progress:function(f){if(live&&ver==="2004"){f=Math.max(0,Math.min(1,f));rawSet("cmi.progress_measure",f.toFixed(2))}},
    commit:function(){
      if(!live)return;
      var t=Date.now()-t0;
      if(ver==="2004"){rawSet("cmi.session_time",dur2004(t));if(!ok(api.Commit("")))warn("Commit")}
      else{rawSet("cmi.core.session_time",dur12(t));try{api.LMSCommit("")}catch(e){}}
    },
    finish:function(){
      if(!live||ended)return;
      for(var h=0;h<hooks.length;h++){try{hooks[h]()}catch(e){}}
      ended=true;
      this.set("cmi.exit","suspend");
      this.commit();
      try{if(ver==="2004")api.Terminate("");else api.LMSFinish("")}catch(e){}
      live=false;
    }
  };
  window.addEventListener("pagehide",function(){SCORM.finish()});
  window.addEventListener("beforeunload",function(){SCORM.finish()});
})();
