/* Interface text in Arabic and English. The course language comes from COURSE_DATA.lang ('ar' | 'en').
   T(key, a, b) returns the text, replacing {a} and {b}. Sets <html lang dir>. */
(function () {
  var S = {
    en: {
      start: 'Start', course: 'COURSE', courseComplete: 'COURSE COMPLETE', station: 'Station', stationOf: 'STATION {a} OF {b}', stationComplete: 'STATION {a} COMPLETE',
      replay: 'Replay this screen', sound: 'Sound on or off', cc: 'Captions on or off', back: 'Previous screen', play: 'Play or pause', next: 'Next screen', home: 'Back to the start screen', index: 'Course index', indexShort: 'Index', help: 'Help', full: 'Full screen', close: 'Close',
      pressPlay: 'Select play to start the narration.', notBuilt: 'This part will be added in the next version.', notAvail: 'This screen is not available yet.', screenOf: 'Screen {a} of {b}', reviewBanner: 'REVIEW COPY · navigation unlocked',
      courseIndex: 'Course Index', pctComplete: '% complete', refDocs: 'Reference Documents', refDoc: 'Reference Document', openTab: 'Open in a new tab',
      howTo: 'How to Use This Course', hReplay: 'Replay this screen', hSound: 'Turn the narration sound on or off', hCC: 'Show the narration text on screen', hBack: 'Go to the previous screen', hPlay: 'Play or pause the narration', hNext: 'Go to the next screen — it unlocks when the screen is complete', hHome: 'Go back to the start screen', hIndex: 'Open the course index', hFull: 'Switch to full screen',
      tip: 'Tip: select Index at the bottom to open the course index.', startBtn: 'Start', intro: 'Introduction', lesson: 'Lesson', lessonOf: 'Lesson {a} of {b}', complete: 'Complete',
      wywl: 'What You Will Learn', byEnd: 'By the end of this course, you will be able to:', answers: 'This course answers one question:', map: 'Your Course Map', total: 'Total', min: 'min', approx: 'approximately',
      achieved: 'What you achieved', nextStep: 'YOUR NEXT STEP', courseDone: 'Course Complete', doneTag: 'You have completed this course',
      select: 'Select each item to explore it.', selectAll: 'Open all items to continue.', choose: 'Choose the best answer.', submit: 'Submit', tryAgain: 'Try again', continueBtn: 'Continue',
      correct: 'Correct.', notQuite: 'Not quite.', correctIs: 'The correct answer is {a}.', bestIs: 'The best choice is {a}.',
      kc: 'Knowledge Check', question: 'Question {a} of {b}', yourScore: 'Your score', passed: 'Passed', notPassed: 'Not passed yet', passMark: 'Pass mark: {a}%', retake: 'Retake',
      sortHint: 'Drag or select each statement, then choose where it belongs.', check: 'Check', allSorted: 'All statements are in the right place.',
      scenario: 'SCENARIO', whatDo: 'What would you do?', decision: 'Decision {a}', outcome: 'Outcome', restart: 'Try another path',
      find: 'Find them all', found: '{a} of {b} found', steps: 'Step {a} of {b}', watch: 'Watch the video to continue.', video: 'VIDEO',
      reflect: 'Reflection', other: 'Other (write your own)', write: 'Write here…', saveRefl: 'Save my answers', saved: 'Saved', print: 'Print my reflection',
      ackTitle: 'Acknowledgment', ackBtn: 'Confirm', ackDone: 'Confirmed', exam: 'Final Assessment', examIntro: '{a} questions drawn from the question bank. Pass mark: {b}%.', startExam: 'Start the assessment',
      dragOr: 'or select', backShort: 'Back', nextShort: 'Next', pctDone: '{a}% complete', qCount: '{a} questions', yes: 'Yes', no: 'No', min1: 'min'
    },
    ar: {
      start: 'البداية', course: 'البرنامج', courseComplete: 'اكتمل البرنامج', station: 'المحطة', stationOf: 'المحطة {a} من {b}', stationComplete: 'اكتملت المحطة {a}',
      replay: 'إعادة الشاشة', sound: 'تشغيل الصوت أو كتمه', cc: 'إظهار النص أو إخفاؤه', back: 'الشاشة السابقة', play: 'تشغيل أو إيقاف مؤقت', next: 'الشاشة التالية', home: 'العودة إلى شاشة البداية', index: 'فهرس البرنامج', indexShort: 'الفهرس', help: 'المساعدة', full: 'ملء الشاشة', close: 'إغلاق',
      pressPlay: 'اضغط زر التشغيل لبدء السرد.', notBuilt: 'سيُضاف هذا الجزء في الإصدار التالي.', notAvail: 'هذه الشاشة غير متاحة بعد.', screenOf: 'الشاشة {a} من {b}', reviewBanner: 'نسخة مراجعة · التنقل مفتوح',
      courseIndex: 'فهرس البرنامج', pctComplete: '% مكتمل', refDocs: 'المراجع', refDoc: 'مرجع', openTab: 'فتح في نافذة جديدة',
      howTo: 'طريقة استخدام البرنامج', hReplay: 'إعادة الشاشة الحالية', hSound: 'تشغيل صوت السرد أو كتمه', hCC: 'إظهار نص السرد على الشاشة', hBack: 'الانتقال إلى الشاشة السابقة', hPlay: 'تشغيل السرد أو إيقافه مؤقتاً', hNext: 'الانتقال إلى الشاشة التالية — يُفتح عند اكتمال الشاشة', hHome: 'العودة إلى شاشة البداية', hIndex: 'فتح فهرس البرنامج', hFull: 'التبديل إلى ملء الشاشة',
      tip: 'تلميح: اضغط «الفهرس» في الأسفل لفتح فهرس البرنامج.', startBtn: 'ابدأ', intro: 'المقدمة', lesson: 'الدرس', lessonOf: 'الدرس {a} من {b}', complete: 'اكتمل',
      wywl: 'ماذا ستتعلم', byEnd: 'في نهاية هذا البرنامج ستكون قادراً على أن:', answers: 'يجيب هذا البرنامج عن سؤال واحد:', map: 'خريطة البرنامج', total: 'المجموع', min: 'دقيقة', approx: 'نحو',
      achieved: 'ما أنجزته', nextStep: 'خطوتك التالية', courseDone: 'اكتمل البرنامج', doneTag: 'أكملت هذا البرنامج',
      select: 'اختر كل عنصر لاستكشافه.', selectAll: 'افتح العناصر كلها للمتابعة.', choose: 'اختر الإجابة الأفضل.', submit: 'تأكيد', tryAgain: 'حاول مرة أخرى', continueBtn: 'متابعة',
      correct: 'إجابة صحيحة.', notQuite: 'ليست الإجابة الأفضل.', correctIs: 'الإجابة الصحيحة هي ({a}).', bestIs: 'الخيار الأفضل هو ({a}).',
      kc: 'اختبر معرفتك', question: 'السؤال {a} من {b}', yourScore: 'نتيجتك', passed: 'ناجح', notPassed: 'لم تجتز بعد', passMark: 'درجة النجاح: {a}%', retake: 'إعادة الاختبار',
      sortHint: 'اسحب كل عبارة إلى مكانها، أو اضغطها ثم اضغط العمود، ثم «تحقّق».', check: 'تحقّق', allSorted: 'كل العبارات في مكانها الصحيح.',
      scenario: 'موقف', whatDo: 'ماذا تفعل؟', decision: 'القرار {a}', outcome: 'النتيجة', restart: 'جرّب مساراً آخر',
      find: 'اكتشفها كلها', found: 'اكتشفت {a} من {b}', steps: 'الخطوة {a} من {b}', watch: 'شاهد الفيديو للمتابعة.', video: 'فيديو',
      reflect: 'تأمّل', other: 'أخرى (اكتب بنفسك)', write: 'اكتب هنا…', saveRefl: 'احفظ إجاباتي', saved: 'تم الحفظ', print: 'اطبع تأمّلي',
      ackTitle: 'إقرار', ackBtn: 'تأكيد', ackDone: 'تم التأكيد', exam: 'التقييم النهائي', examIntro: '{a} سؤالاً تُسحب من بنك الأسئلة. درجة النجاح: {b}%.', startExam: 'ابدأ التقييم',
      dragOr: 'أو اختر', backShort: 'السابق', nextShort: 'التالي', pctDone: 'مكتمل {a}%', qCount: 'عدد الأسئلة: {a}', yes: 'نعم', no: 'لا', min1: 'د'
    }
  };
  var D = window.COURSE_DATA || {}, L = D.lang === 'ar' ? 'ar' : 'en';
  document.documentElement.lang = L; document.documentElement.dir = L === 'ar' ? 'rtl' : 'ltr';
  window.LANG = L;
  window.T = function (k, a, b) { var t = (S[L][k] != null ? S[L][k] : (S.en[k] != null ? S.en[k] : k)); return String(t).replace('{a}', a == null ? '' : a).replace('{b}', b == null ? '' : b); };
  window.LETTERS = L === 'ar' ? ['أ', 'ب', 'ج', 'د', 'هـ', 'و'] : ['A', 'B', 'C', 'D', 'E', 'F'];
})();
