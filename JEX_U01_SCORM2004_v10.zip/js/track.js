/* Lesson & activity tracking for the LMS (SCORM 2004, with 1.2 fallback through SCORM.*)
   - One objective per lesson (cmi.objectives): lesson title + time spent (description), completion status,
     progress within the lesson, and — for lessons with scored items — the first-attempt score.
     The post-assessment lesson also carries passed/failed. The course score itself stays cmi.score (post-assessment).
   - One interaction record per learner attempt (cmi.interactions), linked to its lesson objective.
   - Lesson time = time the learner spends on that lesson's screens while the course is visible, counted up to
     30 minutes after the learner's last action; saved every 30 s, when the course is hidden, and on exit. */
(function(){
  /* Course-specific data comes from js/tracking-config.js (window.TRACKING_CONFIG), loaded before this file:
     lessons : [["<menu name used by the screens>", "<LESSON-CODE>"], ...] in course order
     scored  : {"<LESSON-CODE>": ["<ITEM_ID>", ...]}  items whose first attempt makes up the lesson score
     postCode: lesson code of the post-assessment (default: the code ending in -POST)
     passMark: 0..1 pass threshold for the post-assessment (default 0.8; the LMS value wins if supplied)
     passLessons: {"<LESSON-CODE>": 0..1} lessons that carry their own pass mark (e.g. one knowledge check per lesson).
       The course writes the latest attempt result (0..100) to persist "lr"[code]; the lesson objective then shows
       passed/failed from that latest result, while its score stays the first-attempt score. */
  var CFG=window.TRACKING_CONFIG||{};
  var LESSONS=CFG.lessons||[];
  var SCORED=CFG.scored||{};
  var POST=CFG.postCode||(LESSONS.map(function(l){return l[1]}).filter(function(c){return /-POST$/i.test(c)})[0]);
  var PASS=CFG.passMark!=null?CFG.passMark:0.8;
  var PASSL=CFG.passLessons||{};
  var CODE={},NAME={};
  LESSONS.forEach(function(l){CODE[l[0]]=l[1];NAME[l[1]]=l[0]});
  var IDLE_CAP=30*60*1000, CHECKPOINT=30*1000;
  var api=null,S=null,cur=null,segStart=null,lastAct=Date.now();

  function P(k,def){var v=api.persist(k);if(v==null){v=def;S.persist[k]=v}return v} // read without forcing a save
  function slug(t){var d=document.createElement("div");d.innerHTML=String(t);
    return d.textContent.replace(/&/g," and ").replace(/[^A-Za-z0-9]+/g,"_").replace(/^_+|_+$/g,"").slice(0,40)||"item"}
  function hash(t){var h=5381;for(var i=0;i<t.length;i++)h=((h<<5)+h+t.charCodeAt(i))|0;return (h>>>0).toString(36)}
  function fmt(ms){var s=Math.round(ms/1000),h=Math.floor(s/3600),m=Math.floor(s%3600/60),r=s%60;
    return (h?h+" h ":"")+((h||m)?m+" min ":"")+r+" s"}

  /* ---- lesson time ---- */
  /* time is counted only while the course is visible, and not beyond 30 minutes after the learner's last action */
  function upTo(){return Math.min(Date.now(),lastAct+IDLE_CAP)}
  function stopClock(){
    if(cur&&segStart!=null){
      var dt=upTo()-segStart,lt=P("lt",{});
      if(dt>0)lt[cur]=(lt[cur]||0)+dt;
    }
    segStart=null;
  }
  /* learner action: if the learner had been idle past the cap, close the counted stretch at the cap first */
  function act(){var n=Date.now();if(segStart!=null&&n-lastAct>IDLE_CAP){stopClock();lastAct=n;startClock()}else lastAct=n}
  function startClock(){segStart=document.hidden?null:Date.now()}

  /* ---- lesson objective ---- */
  function lessonState(code){
    var name=NAME[code],ids=S.screens.filter(function(s){return s.menu===name}).map(function(s){return s.id});
    var done=ids.filter(function(id){return S.done[id]}).length,seen=ids.some(function(id){return S.visited[id]});
    var o={completion:done===ids.length&&ids.length?"completed":(seen||done?"incomplete":"not attempted"),progress:ids.length?done/ids.length:0};
    var lt=P("lt",{});
    var live=(code===cur&&segStart!=null)?Math.max(0,upTo()-segStart):0; // include the time running now
    o.desc=name+" — time spent: "+fmt((lt[code]||0)+live);
    var items=SCORED[code],fa=P("fa",{});
    if(items&&items.every(function(id){return fa[id]!=null})){
      var right=items.filter(function(id){return fa[id]===1}).length,pct=Math.round(right/items.length*100);
      o.min="0";o.max="100";o.raw=String(pct);o.scaled=String(pct/100);
      if(code===POST){var cr=SCORM.get("cmi.success_status");o.success=(cr==="passed"||cr==="failed")?cr:(pct/100>=SCORM.passMark(PASS)?"passed":"failed")} // status follows the course result (latest attempt); the score stays first-try
    }
    if(PASSL[code]!=null){var lr=P("lr",{})[code];if(lr!=null)o.success=lr/100>=PASSL[code]?"passed":"failed"} // per-lesson pass mark: status follows the latest attempt
    return o;
  }
  function writeLesson(code,force){
    var o=lessonState(code),sig=P("os",{}),cmp={},k;
    for(k in o)cmp[k]=o[k];
    var key=hash(JSON.stringify(cmp)); // short signature keeps suspend_data small
    if(!force&&sig[code]===key)return false;
    SCORM.objective(code,o); sig[code]=key; return true;
  }
  function writeAll(force){var ch=false;LESSONS.forEach(function(l){if(writeLesson(l[1],force))ch=true});return ch}

  window.Track={
    lessonOf:function(menu){return CODE[menu]},
    start:function(a,state){
      api=a;S=state;
      P("lt",{});P("fa",{});P("os",{});
      SCORM.interactionFloor(P("ic",0)); // interaction index saved by the course itself
      writeAll(false);
      /* save lesson time when the course is hidden or closed (the LMS may end the session before the page unloads),
         and checkpoint it every 30 seconds so a closed window loses at most that much */
      document.addEventListener("visibilitychange",function(){if(document.hidden){Track.flush()}else{lastAct=Date.now();startClock()}});
      ["pointerdown","keydown","touchstart","wheel"].forEach(function(ev){document.addEventListener(ev,act,true)});
      setInterval(function(){if(!document.hidden&&segStart!=null)Track.flush()},CHECKPOINT);
      SCORM.beforeFinish(function(){Track.flush()});
    },
    /* called by the engine each time a screen is shown */
    enter:function(sc){
      if(!api)return;
      var code=CODE[sc.menu];
      act();
      if(code!==cur){stopClock();var prev=cur;cur=code;if(prev)writeLesson(prev);}
      if(segStart==null)startClock();
      if(code)writeLesson(code);
    },
    /* called by the engine when a screen is completed */
    screenDone:function(sc){if(api&&CODE[sc.menu])writeLesson(CODE[sc.menu])},
    /* record one attempt; first attempt of a scored item feeds the lesson score */
    record:function(o){
      if(!api)return;
      var code=o.lesson||CODE[(api.sc||{}).menu];
      var dd=document.createElement("div");dd.innerHTML=String(o.desc||"");
      SCORM.interaction({id:o.id,type:o.type,desc:dd.textContent.replace(/\s+/g," ").trim(),objective:code,correct:o.correct,response:o.response,
        result:o.result,weight:o.result==="neutral"&&o.correct==null?null:1,latencyMs:o.latencyMs});
      S.persist.ic=SCORM.interactionCount();
      if(o.result==="correct"||o.result==="incorrect"){
        var fa=P("fa",{});
        if(fa[o.id]==null)fa[o.id]=o.result==="correct"?1:0;
      }
      api.persist("ic",S.persist.ic); // saves suspend_data (index + first-attempt results)
      if(code){writeLesson(code);SCORM.commit()}
    },
    flush:function(){
      if(!api)return;
      stopClock(); if(cur)writeLesson(cur); api.persist("lt",P("lt",{})); // persist() saves suspend_data and commits
      startClock();
    },
    slug:slug
  };
})();
