/* Ivory e-learning engine — generic, bilingual (configured by window.COURSE from js/build.js; interface text from js/ui.js). */
(function () {
  var C = window.COURSE, PARTS = C.parts, T = window.T;
  var ORDER = [C.start], META = {};
  PARTS.forEach(function (p) { p[2].forEach(function (s, i) { ORDER.push(s[0]); META[s[0]] = { part: p[0], partTitle: p[1], title: s[1], n: i + 1, of: p[2].length, tag: s[2] }; }); });
  META[C.start] = { part: PARTS[0][0], partTitle: PARTS[0][1], title: T('start'), n: 0, of: PARTS[0][2].length };

  var SCREENS = {}, $ = function (id) { return document.getElementById(id); };
  var st = { done: {}, max: 0, muted: false, notes: {}, pt: {}, fa: {}, iq: [], seq: 0, kc: null }, cur = null, audio = null, timers = [], paused = false, locked = false;

  function ico(n) { return window.ico(n); }
  var RTL = document.documentElement.dir === 'rtl';
  /* ---- LMS tracking: ivory-scorm2004-package contract (js/scorm.js + js/track.js + js/tracking-config.js) ---- */
  var MENU = {}; /* screen id -> lesson menu name (must match TRACKING_CONFIG.lessons) */
  C.menu.forEach(function (g) { g[1].forEach(function (id) { MENU[id] = g[0]; }); });
  var TS = { screens: [], visited: {}, done: st.done, persist: {} }, TAPI = null;
  function scr(id) { for (var i = 0; i < TS.screens.length; i++) if (TS.screens[i].id === id) return TS.screens[i]; return null; }
  function save() {
    var x = TS.persist; x.n = st.notes; x.k = st.kc; x.a = st.ack || null; x.h = st.hintIdx || 0; x.mx = st.max; x.cc = st.cc ? 1 : 0;
    var total = TS.screens.length, d = Object.keys(st.done).filter(function (k) { return MENU[k]; });
    if (cur) SCORM.set('cmi.location', cur);
    var data = JSON.stringify({ v: Object.keys(TS.visited), d: d, x: x });
    if (data.length > SCORM.maxSuspend()) { delete x.n; data = JSON.stringify({ v: Object.keys(TS.visited), d: d, x: x }); }
    SCORM.set('cmi.suspend_data', data);
    SCORM.progress(total ? d.length / total : 0);
    SCORM.commit();
  }
  function persist(k, v) { if (arguments.length < 2) return TS.persist[k]; TS.persist[k] = v; save(); return v; }
  function track(o) { if (window.Track) Track.record(o); }
  function quizResult(score, passed) {
    st.kc.last = score; st.kc.passed = st.kc.passed || passed;
    var post = Math.round(score * 100), pass = SCORM.passMark(0.8);
    SCORM.set('cmi.score.min', '0'); SCORM.set('cmi.score.max', '100');
    SCORM.set('cmi.score.raw', String(post)); SCORM.set('cmi.score.scaled', String(post / 100));
    SCORM.set('cmi.success_status', st.kc.passed || post / 100 >= pass ? 'passed' : 'failed');
    SCORM.set('cmi.completion_status', 'completed');
    if (window.Track) Track.screenDone({ menu: C.postMenu || 'Post-Assessment' });
    save();
  }
  function lockNav(on) {
    if (window.REVIEW) on = false;
    locked = on; ['b-back', 'b-next', 'b-home', 'b-idx'].forEach(function (k) { $(k).classList.toggle('off', on); });
    if (!on) { $('b-back').className = 'b' + (ORDER.indexOf(cur) <= 1 ? ' off' : ''); setNext(!!st.done[cur]); }
  }

  /* ---------- stage scaling ---------- */
  /* the stage is re-fitted whenever the frame changes size: LMS frames are often sized after load, and full screen changes them again */
  var fitT = null; function refit() { clearTimeout(fitT); fitT = setTimeout(fit, 60); }
  window.addEventListener('resize', refit); window.addEventListener('orientationchange', refit);
  ['fullscreenchange', 'webkitfullscreenchange'].forEach(function (e) { document.addEventListener(e, function () { fit(); refit(); }); });
  if (window.ResizeObserver) new ResizeObserver(refit).observe(document.documentElement);
  [150, 500, 1200, 2500].forEach(function (t) { setTimeout(fit, t); });
  function fit() {
    var W = window.innerWidth || document.documentElement.clientWidth, H = window.innerHeight || document.documentElement.clientHeight; if (!W || !H) return;
    var s = Math.min(W / 1920, H / 1080), stg = $('stage');
    stg.style.transform = 'scale(' + s + ')';
    stg.style.left = Math.max(0, (W - 1920 * s) / 2) + 'px';
    stg.style.top = Math.max(0, (H - 1080 * s) / 2) + 'px';
  }

  /* ---------- chrome ---------- */
  function arcs() {
    var h = ''; for (var r = 300; r <= 1180; r += 44) h += '<circle cx="1985" cy="1135" r="' + r + '" stroke="#EAE7E7" stroke-width="7"/><circle cx="1985" cy="1135" r="' + (r - 5) + '" stroke="#F8F8F8" stroke-width="2"/>';
    $('arcs').innerHTML = h;
  }
  function tracker(final) {
    var J = C.journey, t = '';
    if (!J) { $('trk').innerHTML = '<div class="crs"><small>' + (final ? T('courseComplete') : T('course')) + '</small>' + C.short + '</div>'; return; }
    var N = J.names.length;
    J.names.forEach(function (nm, k) {
      var n = k + 1, cls = n < J.current ? 'done' : (n === J.current ? (final ? 'done cur' : 'cur') : 'x');
      t += '<div class="st ' + cls + '" title="' + T('station') + ' ' + n + ': ' + nm + '"><div class="d">' + (cls.indexOf('done') >= 0 ? ico('check') : n) + '</div>' +
        (n === J.current ? '<div class="lb"><small>' + (final ? T('stationComplete', n) : T('stationOf', n, N)) + '</small>' + C.short + '</div>' : '') + (k < N - 1 ? '<div class="ln"></div>' : '') + '</div>';
    });
    $('trk').innerHTML = t;
  }
  function buildBar() {
    var B = [['replay', 'rotate-left', 140, T('replay')], ['sound', 'volume-high', 190, T('sound')], ['back', 'arrow-left', 905, T('back')], ['play', 'pause', 947, T('play')], ['next', 'arrow-right', 989, T('next')], ['home', 'house', 1500, T('home')], ['idx', 'list', 1556, T('index')], ['helpb', 'question', 1698, T('help')], ['full', 'expand', 1748, T('full')]];
    $('bar').innerHTML = B.map(function (b) { return '<button class="b" id="b-' + b[0] + '" style="left:' + (b[2] - 7) + 'px" aria-label="' + b[3] + '" title="' + b[3] + '">' + ico(b[1]) + (b[0] === 'idx' ? '<span class="idxl">' + T('indexShort') + '</span>' : '') + '</button>'; }).join('');
    if (RTL) B.forEach(function (b) { var e = $('b-' + b[0]); e.style.left = (1920 - b[2] + 7 - e.offsetWidth) + 'px'; });
    /* RTL bar: home · index · help · full screen on the right; replay · sound on the left;
       next (→) right of play and previous (←) left of play */
    if (RTL) { var X = { home: 1800, idx: 1664, helpb: 1604, full: 1548, replay: 182, sound: 128, back: 874, play: 938, next: 1002 };
      Object.keys(X).forEach(function (k) { var e = $('b-' + k); if (!e) return; e.style.left = (k === 'idx' ? X.idx + 120 - e.offsetWidth : X[k]) + 'px'; }); }
    $('b-replay').onclick = function () { go(cur, true); };
    $('b-sound').onclick = function () { st.muted = !st.muted; if (audio) audio.muted = st.muted; $('b-sound').innerHTML = ico(st.muted ? 'volume-xmark' : 'volume-high'); SCORM.set('cmi.learner_preference.audio_level', st.muted ? '0' : '1'); save(); };
    $('b-sound').innerHTML = ico(st.muted ? 'volume-xmark' : 'volume-high');
    if ($('b-cc')) $('b-cc').onclick = function () { st.cc = !st.cc; ccBtn(); ccShow(st.cc && ccCur ? ccCur : ''); save(); }; ccBtn();
    $('b-back').onclick = function () { if (locked) return; var i = ORDER.indexOf(cur); if (i > 1) go(ORDER[i - 1]); };
    $('b-next').onclick = next;
    $('b-play').onclick = togglePause;
    $('b-home').onclick = function () { if (!locked || window.REVIEW) go(C.start); };
    $('b-idx').onclick = function () { if (!locked || window.REVIEW) openIndex(); };
    $('b-helpb').onclick = openHelp;
    $('b-full').onclick = function () { var d = document; if (!d.fullscreenElement) { (d.documentElement.requestFullscreen || function () { }).call(d.documentElement); } else if (d.exitFullscreen) d.exitFullscreen(); };
  }
  function setNext(ready) { if (window.REVIEW) ready = true; var b = $('b-next'); b.className = 'b ' + (ready ? 'ready' : 'off'); b.setAttribute('aria-disabled', ready ? 'false' : 'true'); }
  function setPlayIcon() { $('b-play').innerHTML = ico(paused || !audio ? 'play' : 'pause'); }

  /* ---------- audio with phrase cues ---------- */
  function clearTimers() { timers.forEach(clearTimeout); timers = []; }
  /* ---------- captions: narration text under the screen ---------- */
  var ccSeg = [], ccCur = '';
  function ccBtn() { var b = $('b-cc'); if (b) { b.classList.toggle('on', !!st.cc); b.setAttribute('aria-pressed', st.cc ? 'true' : 'false'); } }
  function ccShow(t) { var e = $('cc'); if (!e) { e = document.createElement('div'); e.id = 'cc'; e.setAttribute('aria-live', 'polite'); $('stage').appendChild(e); } e.textContent = t || ''; e.style.display = t ? 'block' : 'none'; }
  function ccPrep(text, dur) { var parts = String(text).match(/[^.!?]+[.!?]+["”’]?\s*|[^.!?]+$/g) || [text], tot = text.length || 1, acc = 0; ccSeg = parts.map(function (p) { var s0 = acc / tot * dur; acc += p.length; return { t: s0, x: p.trim() }; }); ccCur = ccSeg.length ? ccSeg[0].x : ''; if (st.cc) ccShow(ccCur); }
  function ccAt(t) { if (!ccSeg.length) return; var x = ccSeg[0].x; ccSeg.forEach(function (g) { if (t >= g.t) x = g.x; }); if (x !== ccCur) { ccCur = x; if (st.cc) ccShow(x); } }
  function stopAudio() {
    if (audio) { audio.onended = null; audio.ontimeupdate = null; audio.onerror = null; audio.pause(); audio = null; }
    paused = false; ccSeg = []; ccCur = ''; ccShow('');
  }
  function say(id, cues, onEnd) {
    stopAudio();
    var text = window.TXT[id] || '', dur = window.DUR[id] || 3, list = [];
    (cues || []).forEach(function (c) {
      var i = text.indexOf(c[0]); if (i < 0) i = text.toLowerCase().indexOf(String(c[0]).toLowerCase());
      list.push({ t: i < 0 ? dur * 0.95 : (i / text.length) * dur, fn: c[1], done: false }); /* a cue that is not in the text never fires early */
    });
    var path = 'assets/audio/' + id + '.mp3', a = new Audio((window.ASSET && window.ASSET[path]) || path); a.muted = st.muted; audio = a;
    function fire(t) { list.forEach(function (c) { if (!c.done && t >= c.t - 0.05) { c.done = true; c.fn(); } }); }
    ccPrep(text, dur);
    a.ontimeupdate = function () { fire(a.currentTime); ccAt(a.currentTime); };
    a.onended = function () { fire(1e9); audio = null; setPlayIcon(); later(1200, function () { if (!audio) { ccCur = ''; ccShow(''); } }); if (onEnd) onEnd(); };
    a.onerror = function () {
      /* audio could not load: run the screen on the measured timing so the learner is never blocked */
      if (audio !== a) return; audio = null; setPlayIcon();
      list.forEach(function (c) { later(c.t * 1000, function () { if (!c.done) { c.done = true; c.fn(); } }); });
      later(dur * 1000, function () { if (onEnd) onEnd(); });
    };
    var p = a.play();
    if (p && p.catch) p.catch(function (e) {
      if (audio !== a || (e && e.name !== 'NotAllowedError')) return;
      /* autoplay blocked: wait for the play button */
      paused = true; setPlayIcon(); toast(T('pressPlay'));
    });
    setPlayIcon();
    return a;
  }
  function togglePause() {
    if (!audio) return;
    if (audio.paused) { audio.play(); paused = false; } else { audio.pause(); paused = true; }
    setPlayIcon();
  }
  function later(ms, fn) { var t = setTimeout(fn, ms); timers.push(t); return t; }
  function toast(msg) { var t = $('toast'); t.textContent = msg; t.style.display = 'block'; clearTimeout(t._h); t._h = setTimeout(function () { t.style.display = 'none'; }, 3200); }

  /* ---------- screen lifecycle ---------- */
  function complete(keepNextLocked) {
    st.done[cur] = 1; var sc = scr(cur); if (sc && window.Track) Track.screenDone(sc);
    setNext(cur !== C.last && !keepNextLocked); save();
    var i = ORDER.indexOf(cur); if (i + 1 > st.max) st.max = i + 1;
  }
  function next() {
    if ((!st.done[cur] || locked) && !window.REVIEW) return;
    var i = ORDER.indexOf(cur), n = ORDER[i + 1];
    if (n && SCREENS[n]) go(n); else toast(T('notBuilt'));
  }
  function go(id, replay) {
    if (!SCREENS[id]) { toast(T('notAvail')); return; }
    stopAudio(); clearTimers(); closeOverlays(); locked = false; $('b-home').classList.remove('off'); $('b-idx').classList.remove('off');
    cur = id; var m = META[id], s = SCREENS[id], c = $('content');
    var i = ORDER.indexOf(id); if (i > st.max) st.max = i;
    var start = id === C.start;
    ['trk', 'part', 'title', 'bar', 'logo', 'bg', 'slgh'].forEach(function (k) { if ($(k)) $(k).classList.toggle('hide', start); });
    if (!start) {
      tracker(id === C.last && C.isFinal(st));
      $('pt').textContent = C.partLabel(m);
      $('sc').textContent = T('screenOf', m.n, m.of);
      $('pb').style.width = (m.n / m.of * 100) + '%';
      $('tt').innerHTML = s.title || m.title; var tt = $('tt'); tt.classList.remove('tin'); void tt.offsetWidth; tt.classList.add('tin');
      $('b-back').className = 'b' + (i <= 1 ? ' off' : '');
      setNext(!!st.done[id]);
    }
    if (!start && !st.hintIdx) { st.hintIdx = 1; later(900, function () { toast(T('tip')); }); }
    TS.visited[id] = 1; var sc = scr(id); if (TAPI) TAPI.sc = sc; if (sc && window.Track) Track.enter(sc);
    c.innerHTML = ''; c.className = '';
    s.render(c, api, { revisit: !!st.done[id], replay: !!replay });
    setPlayIcon(); save(); preload(i);
  }
  /* warm the browser cache with the pictures, posters and narration of the next two screens, so titles and slides arrive together */
  var PRE = {}; function preload(i) { [1, 2].forEach(function (d) { var k = ORDER[i + d]; if (!k || PRE[k]) return; PRE[k] = 1;
    var S = (window.SCREEN_MEDIA || {})[k] || []; S.forEach(function (u) { var im = new Image(); im.src = u; });
    try { var au = new Audio(); au.preload = 'auto'; au.src = 'assets/audio/' + k + '.mp3'; } catch (e) { } }); }
  var api = {
    say: say, later: later, complete: complete, toast: toast, ico: ico, next: next, go: go, state: st,
    isDone: function (id) { return !!st.done[id]; },
    reveal: function (el, cls) { if (el) el.classList.add(cls || 'in'); },
    lessonResult: function (code, pct) {
      var lr = persist('lr') || {}; lr[code] = pct; persist('lr', lr);
      var name = null; C.menu.forEach(function (g) { if (window.TRACKING_CONFIG.lessons.some(function (x) { return x[1] === code && x[0] === g[0]; })) name = g[0]; });
      if (window.Track && name) Track.screenDone({ menu: name });
      var need = Object.keys(window.TRACKING_CONFIG.passLessons || {}), got = need.filter(function (k) { return lr[k] != null; });
      if (got.length === need.length) {
        var avg = Math.round(got.reduce(function (s, k) { return s + lr[k]; }, 0) / got.length), all = got.every(function (k) { return lr[k] >= (C.passPct || 80); });
        SCORM.set('cmi.score.min', '0'); SCORM.set('cmi.score.max', '100'); SCORM.set('cmi.score.raw', String(avg)); SCORM.set('cmi.score.scaled', String(avg / 100));
        SCORM.set('cmi.success_status', all ? 'passed' : 'failed'); if (all) SCORM.set('cmi.completion_status', 'completed');
      }
      save();
    },
    save: save, openDoc: openDoc, track: track, quizResult: quizResult, persist: persist, lockNav: lockNav
  };

  /* ---------- overlays ---------- */
  function closeOverlays() { ['shade', 'idx', 'help'].forEach(function (k) { $(k).classList.remove('show'); }); }
  function openIndex() {
    var total = ORDER.length - 1, done = 0; ORDER.forEach(function (k) { if (st.done[k] && k !== C.start) done++; });
    var pct = Math.round(done / total * 100), h = '<div class="hd"><h3>' + T('courseIndex') + '</h3><div class="sb">' + C.title + '</div><div class="pg"><i style="width:' + pct + '%"></i></div><div class="pc">' + T('pctDone', pct) + '</div><button class="x" id="idx-x" aria-label="Close index">' + ico('xmark') + '</button></div><div class="list">';
    var curPart = META[cur] ? META[cur].part : '1';
    PARTS.forEach(function (p) {
      var ids = p[2].map(function (s) { return s[0]; }), nd = ids.filter(function (k) { return st.done[k]; }).length;
      var cls = nd === ids.length ? 'dn' : (p[0] === curPart ? 'cu' : ((ORDER.indexOf(ids[0]) <= st.max || window.REVIEW) && SCREENS[ids[0]] ? '' : 'lk'));
      h += '<div class="sec ' + cls + '"><span class="n">' + (cls === 'dn' ? ico('check') : ({ '0': ico('book-open'), 'P': ico('clipboard-question'), 'E': ico('clipboard-check'), 'C': ico('flag-checkered') }[p[0]] || p[0])) + '</span>' + C.secLabel(p) + '<span class="c">' + nd + '/' + ids.length + '</span></div>';
      if (p[0] === curPart || cls === 'dn' || window.REVIEW) p[2].forEach(function (s) {
        var k = s[0], open = SCREENS[k] && (st.done[k] || ORDER.indexOf(k) <= st.max || window.REVIEW), c2 = k === cur ? 'cu' : (st.done[k] ? 'dn' : (open ? '' : 'lk'));
        h += '<button class="it ' + c2 + '" data-k="' + k + '"' + (open ? '' : ' disabled') + '><span class="s">' + (c2 === 'dn' ? ico('check') : '') + '</span>' + s[1] + (s[2] ? '<span class="tg">' + s[2] + '</span>' : '') + '</button>';
      });
    });
    if (DOCS.length) h += '<div class="res"><div class="rh">' + ico('book-open') + T('refDocs') + '</div>' + DOCS.map(function (d) { return '<button class="rd" data-f="' + d[0] + '">' + ico('file-lines') + '<span>' + d[1] + '</span></button>'; }).join('') + '</div>';
    $('idx').innerHTML = h + '</div>';
    Array.prototype.forEach.call($('idx').querySelectorAll('button.rd'), function (b) { b.onclick = function () { openDoc(b.getAttribute('data-f')); }; });
    $('idx-x').onclick = closeOverlays;
    Array.prototype.forEach.call($('idx').querySelectorAll('button.it'), function (b) { b.onclick = function () { go(b.getAttribute('data-k')); }; });
    $('shade').classList.add('show'); $('idx').classList.add('show');
  }
  var DOCS = C.docs || [];
  function openDoc(f) {
    if (window.DOCS_DATA && window.DOCS_DATA[f]) {
      var bin = atob(window.DOCS_DATA[f]), arr = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      var url = URL.createObjectURL(new Blob([arr], { type: 'application/pdf' })), wb = window.open(url, '_blank');
      if (!wb) { var ov = document.getElementById('docv'); ov.querySelector('iframe').src = url; ov.classList.add('show'); }
      return true;
    }
    var path = 'assets/docs/' + f, url = path;
    if (window.ASSET && window.ASSET[path]) {
      var b64 = window.ASSET[path].split(',')[1], bin = atob(b64), arr = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      url = URL.createObjectURL(new Blob([arr], { type: 'application/pdf' }));
    }
    var w = null; try { w = window.open(url, '_blank'); } catch (e) { w = null; }
    if (!w) { showDoc(url); return true; }
    try { w.opener = null; } catch (e) { } return true;
  }
  function showDoc(url) {
    var o = document.getElementById('docv');
    if (!o) { o = document.createElement('div'); o.id = 'docv'; document.body.appendChild(o); }
    o.innerHTML = '<div class="dh"><span>' + T('refDoc') + '</span><a href="' + url + '" target="_blank" rel="noopener">' + T('openTab') + '</a><button id="docx" aria-label="' + T('close') + '">✕</button></div><iframe src="' + url + '" title="Reference document"></iframe>';
    o.style.display = 'flex'; document.getElementById('docx').onclick = function () { o.style.display = 'none'; o.innerHTML = ''; };
  }
  function openHelp() {
    var R = [['rotate-left', T('hReplay')], ['volume-high', T('hSound')], ['arrow-left', T('hBack')], ['play', T('hPlay')], ['arrow-right', T('hNext')], ['house', T('hHome')], ['list', T('hIndex')], ['expand', T('hFull')]];
    var h = '<h3>' + T('howTo') + '<button id="help-x" aria-label="' + T('close') + '"><span>' + ico('xmark') + '</span></button></h3><div class="r">';
    R.forEach(function (r) { h += '<span class="k">' + ico(r[0]) + '</span><span>' + r[1] + '</span>'; });
    $('help').innerHTML = h + '</div>';
    $('help-x').onclick = closeOverlays;
    $('shade').classList.add('show'); $('help').classList.add('show');
  }

  /* ---------- boot ---------- */
  window.ENGINE = {
    register: function (id, def) { SCREENS[id] = def; },
    start: function () {
      if (window.REVIEW_MODE || /review/i.test(location.hash)) window.REVIEW = true;
      SCORM.init();
      ORDER.forEach(function (id) { TS.screens.push({ id: id, menu: MENU[id] }); });
      var raw = SCORM.get('cmi.suspend_data'), sd = null; try { sd = raw ? JSON.parse(raw) : null; } catch (e) { sd = null; }
      if (sd && sd.x) {
        (sd.v || []).forEach(function (k) { TS.visited[k] = 1; }); (sd.d || []).forEach(function (k) { st.done[k] = 1; });
        TS.persist = sd.x; st.notes = sd.x.n || {}; st.kc = sd.x.k || null; st.ack = sd.x.a || null; st.hintIdx = sd.x.h || 0; st.max = sd.x.mx || 0; st.cc = !!sd.x.cc;
      }
      st.muted = SCORM.get('cmi.learner_preference.audio_level') === '0';
      TAPI = { persist: persist, sc: null, scorm: SCORM };
      if (window.Track) Track.start(TAPI, TS);
      if (C.onStart) C.onStart(api);
      if (window.REVIEW) $('stage').classList.add('review');
      arcs(); buildBar(); (function () { var D0 = window.COURSE_DATA || {}; if (D0.slogan) { var im = document.createElement('img'); im.id = 'slgh'; im.src = D0.slogan; im.alt = 'وسّع نجاحك'; $('stage').insertBefore(im, $('content')); } })(); fit();
      if (window.REVIEW) { var rb = document.createElement('div'); rb.id = 'rvb'; rb.textContent = T('reviewBanner'); $('stage').appendChild(rb); }
      $('shade').onclick = closeOverlays;
      document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeOverlays(); });
      var loc = SCORM.get('cmi.location');
      if (st.muted) $('b-sound').innerHTML = ico('volume-xmark');
      ENGINE.resumeTo = (loc && SCREENS[loc] && loc !== C.start) ? loc : null;
      go(C.start);
    },
    api: api, META: META, ORDER: ORDER
  };
})();
