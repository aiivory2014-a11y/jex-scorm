/* Turns window.COURSE_DATA (js/course.js) into what the engine and tracker read:
   window.COURSE, window.TRACKING_CONFIG, window.TXT (narration text) and window.DUR (estimated durations).
   Screen ids: S0 start · S1 What You Will Learn · L<n>-<k> lesson screens · EX final assessment · S9 completion. */
(function () {
  var D = window.COURSE_DATA, T = window.T, code = D.code || 'COURSE';
  var TXT = window.TXT = window.TXT || {}, DUR = window.DUR = window.DUR || {};
  function tx(id, t) { if (!t) return; TXT[id] = t; if (!DUR[id]) DUR[id] = Math.max(2.5, String(t).split(/\s+/).length / 2.3 + 0.8); }
  var PARTS = [['0', T('intro'), []]], MENU = [[T('intro'), ['S0']]], LES = [[T('intro'), code + '-INT']], SCORED = {}, PASSL = {};
  /* intro screens (lesson code -INT): shown after the start screen, before What You Will Learn */
  var INTRO = { code: code + '-INT', title: T('intro') };
  (D.intro || []).forEach(function (s, k) {
    var id = 'I-' + (k + 1); s.id = id; s.lesson = INTRO; s.n = 0; PARTS[0][2].push([id, s.title || T(s.type), '']); MENU[0][1].push(id); tx(id, s.say);
    if (s.type === 'sort') SCORED[INTRO.code] = (SCORED[INTRO.code] || []).concat([code + '_L0_SORT' + (k + 1)]);
    (s.options || []).forEach(function (o, j) { if (o.fb) tx(id + '-F' + (j + 1), o.fb); });
  });
  PARTS[0][2].push(['S1', T('wywl'), '']); MENU[0][1].push('S1');
  tx('S1', D.objectivesSay || (T('byEnd') + ' ' + (D.objectives || []).join(' ')));
  /* pre-assessment (lesson code -PRE): diagnostic only, never counts toward the course result */
  if (D.pre) { var pre = code + '-PRE', pt = D.pre.title; PARTS.push(['P', pt, [['PR', pt, '']]]); MENU.push([pt, ['PR']]); LES.push([pt, pre]); tx('PR', D.pre.say);
    SCORED[pre] = D.pre.questions.map(function (q, j) { return 'PRE_Q' + (j + 1); }); }
  (D.lessons || []).forEach(function (l, i) {
    var n = i + 1, ids = [];
    l.code = l.code || (code + '-L' + (n < 10 ? '0' : '') + n);
    l.screens.forEach(function (s, k) {
      var id = 'L' + n + '-' + (k + 1); s.id = id; s.lesson = l; s.n = n; ids.push([id, s.title || T(s.type), s.tag || '']);
      tx(id, s.say);
      var items = [];
      if (s.type === 'quiz') { s.questions.forEach(function (q, j) { items.push(code + '_L' + n + '_Q' + (j + 1)); }); PASSL[l.code] = (s.pass || D.passPct || 80) / 100; }
      if (s.type === 'scenario' && !s.poll) items.push(code + '_L' + n + '_S' + (k + 1));
      if (s.type === 'sort') items.push(code + '_L' + n + '_SORT' + (k + 1));
      if (items.length) SCORED[l.code] = (SCORED[l.code] || []).concat(items);
      (s.options || []).forEach(function (o, j) { if (o.fb) tx(id + '-F' + (j + 1), o.fb); });
    });
    PARTS.push([String(n), l.title, ids]); MENU.push([l.title, ids.map(function (x) { return x[0]; })]); LES.push([l.title, l.code]);
  });
  var post = null;
  if (D.exam) { post = code + '-POST'; PARTS.push(['E', D.exam.title || T('exam'), [['EX', D.exam.title || T('exam'), '']]]); MENU.push([D.exam.title || T('exam'), ['EX']]); LES.push([D.exam.title || T('exam'), post]); tx('EX', D.exam.say);
    var ng = D.exam.groups || D.exam.draw || D.exam.bank.length; SCORED[post] = []; for (var g = 1; g <= ng; g++) SCORED[post].push('POST_Q' + g); }
  PARTS.push(['C', T('complete'), [['S9', D.journey ? T('stationComplete', D.journey.current) : T('courseDone'), '']]]);
  tx('S9', (D.close || {}).say);
  var N = (D.lessons || []).length;
  function lab(p, m) { if (p === '0') return T('intro'); if (p === 'C') return T('complete'); if (p === 'E') return D.exam.title || T('exam'); if (p === 'P') return D.pre.title; return T('lessonOf', p, N) + ' — ' + m; }
  window.COURSE = {
    title: D.title, short: D.short || D.title, start: 'S0', last: 'S9', parts: PARTS, menu: MENU, journey: D.journey || null, docs: D.docs || [],
    passPct: D.passPct || 80, postMenu: D.exam ? (D.exam.title || T('exam')) : null,
    partLabel: function (m) { return lab(m.part, m.partTitle); }, secLabel: function (p) { return lab(p[0], p[1]); }, isFinal: function () { return true; }
  };
  /* pictures used by each screen (for preloading the next screens) */
  var SM = {}; function med(id, sc) { var u = []; if (sc.image) u.push(sc.image); if (sc.poster) u.push(sc.poster); if (u.length) SM[id] = u; }
  (D.intro || []).forEach(function (sc) { med(sc.id, sc); });
  (D.lessons || []).forEach(function (l, n) { l.screens.forEach(function (sc, k) { med('L' + (n + 1) + '-' + (k + 1), sc); }); });
  window.SCREEN_MEDIA = SM;
  window.TRACKING_CONFIG = { lessons: LES, scored: SCORED, passLessons: PASSL, postCode: post || undefined, passMark: (D.exam ? (D.exam.pass || D.passPct || 80) : (D.passPct || 80)) / 100 };
})();
